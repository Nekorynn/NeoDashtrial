#!/usr/bin/env python3
"""Apply the NeoDash 0.3.2 permission wizard, cyberpunk dashboard and source selection UI."""
from pathlib import Path
import re, sys

project = Path(sys.argv[1])
java_path = project / "app/src/main/java/com/neodash/launcher/MainActivity.java"
manifest_path = project / "app/src/main/AndroidManifest.xml"
gradle_path = project / "app/build.gradle"

java = java_path.read_text(encoding="utf-8")
manifest = manifest_path.read_text(encoding="utf-8")
gradle = gradle_path.read_text(encoding="utf-8")

def replace_method(source, signature, next_signature, replacement):
    start = source.find(signature)
    if start < 0:
        raise SystemExit("Missing method: " + signature)
    end = source.find(next_signature, start + len(signature))
    if end < 0:
        raise SystemExit("Missing method boundary after: " + signature)
    return source[:start] + replacement + "\n\n    " + source[end:]

# Imports required by the permission wizard, embedded map and media transport controls.
for marker, import_line in [
    ("import android.app.Activity;", "import android.Manifest;\nimport android.app.Activity;"),
    ("import android.content.pm.ResolveInfo;", "import android.content.pm.PackageManager;\nimport android.content.pm.ResolveInfo;"),
    ("import android.graphics.drawable.Drawable;", "import android.location.Location;\nimport android.location.LocationManager;\nimport android.media.AudioManager;\nimport android.net.Uri;\nimport android.graphics.drawable.Drawable;"),
    ("import android.widget.TextView;", "import android.webkit.WebSettings;\nimport android.webkit.WebView;\nimport android.widget.TextView;"),
]:
    added_import = import_line.split("\n")[0]
    if added_import not in java:
        java = java.replace(marker, import_line, 1)

# Premium blue-chrome palette: deep graphite panels, controlled blue/cyan edge lighting.
java = java.replace("private static final int BG = Color.rgb(16, 18, 21);", "private static final int BG = Color.rgb(7, 12, 19);")
java = java.replace("private static final int PANEL = Color.rgb(25, 29, 33);", "private static final int PANEL = Color.rgb(13, 22, 32);")
java = java.replace("private static final int PANEL_HI = Color.rgb(33, 39, 44);", "private static final int PANEL_HI = Color.rgb(19, 32, 45);")
java = java.replace("private static final int BLUE = Color.rgb(22, 139, 255);", "private static final int BLUE = Color.rgb(25, 155, 238);")
java = java.replace("private static final int CYAN = Color.rgb(0, 217, 255);", "private static final int CYAN = Color.rgb(83, 207, 255);")
java = java.replace("private static final int MUTED = Color.rgb(144, 160, 182);", "private static final int MUTED = Color.rgb(133, 163, 185);")
java = java.replace("private static final int WHITE = Color.rgb(239, 246, 255);", "private static final int WHITE = Color.rgb(222, 237, 249);")
java = java.replace("private static final int LINE = Color.rgb(55, 67, 73);", "private static final int LINE = Color.rgb(43, 78, 103);")

# Add subtle illumination only to blue/cyan type; avoid heavy, cheap-looking bloom.
java = java.replace(
'''        v.setIncludeFontPadding(false);
        return v;
''',
'''        v.setIncludeFontPadding(false);
        if (color == CYAN || color == BLUE) v.setShadowLayer(2.2f, 0f, 0f, Color.argb(95, 42, 168, 255));
        return v;
''', 1)

# Add fields for the new setup, page navigation and selected app sources.
field_marker = '    private static final String DASHBOARD_TIME_ZONE = "Asia/Manila";'
fields = '''    private static final String DASHBOARD_TIME_ZONE = "Asia/Manila";
    private static final int REQUEST_SETUP_PERMISSIONS = 520;
    private static final String PREF_SETUP_COMPLETE = "setup_complete";
    private boolean setupUiVisible = false;
    private boolean mapMode = false;
    private int shortcutPage = 0;
    private WebView mapWebView;
    private double mapLatitude = Double.NaN;
    private double mapLongitude = Double.NaN;
'''
if field_marker in java:
    java = java.replace(field_marker, fields.rstrip(), 1)
else:
    raise SystemExit("Field insertion point not found")

# Startup must never start the location foreground service before runtime permission checks.
oncreate = '''    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("neodash", MODE_PRIVATE);
        neon = prefs.getBoolean("neon", true);
        iconScale = prefs.getInt("icon_scale", 1);
        shortcutPage = prefs.getInt("shortcut_page", 0);
        Set<String> savedRecent = prefs.getStringSet("recent_packages", new LinkedHashSet<String>());
        if (savedRecent != null) recentPackages.addAll(savedRecent);
        applyImmersiveMode();
        if (prefs.getBoolean(PREF_SETUP_COMPLETE, false) && hasAllRequiredPermissions()) {
            enterDashboard();
        } else if (hasAllRequiredPermissions()) {
            showConfigurationWizard();
        } else {
            showPermissionSetup();
        }
    }
'''
java = replace_method(java, "    @Override\n    public void onCreate(Bundle state)", "    private void applyImmersiveMode()", oncreate)

# Main dashboard: left is clock/media, right is a four-app page with a permanent next arrow.
build_and_helpers = r'''    private void enterDashboard() {
        setupUiVisible = false;
        prefs.edit().putBoolean(PREF_SETUP_COMPLETE, true).apply();
        startConnectionMonitorIfAllowed();
        buildHome();
    }

    private void startConnectionMonitorIfAllowed() {
        if (!hasAllRequiredPermissions()) return;
        Intent monitor = new Intent(this, NeoDashConnectionManager.class);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(monitor);
            else startService(monitor);
        } catch (RuntimeException ex) {
            Toast.makeText(this, "Connection monitor could not start. Check permissions in Settings.", Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout buildClockMediaPane() {
        LinearLayout left = column();
        left.setPadding(dp(18), dp(14), dp(18), dp(12));
        left.setBackground(panel(PANEL, LINE, 18));
        clockView = label("--:--", 56, WHITE, true);
        clockView.setSingleLine(true);
        clockView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        clockView.setLetterSpacing(-0.025f);
        LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(-1, dp(72));
        clockParams.topMargin = dp(1);
        left.addView(clockView, clockParams);
        dateView = label("VERIFYING DATE & TIME", 13, MUTED, false);
        left.addView(dateView);
        timeProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        timeProgress.setIndeterminate(true);
        timeProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(CYAN));
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(190), dp(4));
        progressParams.topMargin = dp(9);
        left.addView(timeProgress, progressParams);
        timeStatusView = label("Checking trusted time sources...", 10, MUTED, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, dp(23));
        statusParams.topMargin = dp(3);
        left.addView(timeStatusView, statusParams);

        View divider = new View(this);
        divider.setBackgroundColor(LINE);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(11);
        dividerParams.bottomMargin = dp(10);
        left.addView(divider, dividerParams);
        addMediaHub(left);
        return left;
    }

    private void addMediaHub(LinearLayout parent) {
        LinearLayout hub = column();
        hub.setPadding(dp(12), dp(10), dp(12), dp(10));
        hub.setBackground(panel(PANEL_HI, Color.rgb(36, 104, 145), 15));
        LinearLayout heading = row();
        heading.addView(label("MEDIA SYSTEM", 12, CYAN, true));
        View gap = new View(this);
        heading.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        heading.addView(label("SOURCE", 9, MUTED, true));
        hub.addView(heading, new LinearLayout.LayoutParams(-1, dp(22)));

        LinearLayout sources = row();
        sources.setPadding(0, dp(7), 0, dp(8));
        String selected = prefs.getString("last_media_source", "local");
        addMediaSource(sources, "LOCAL", "local", selected);
        addMediaSource(sources, "BLUETOOTH", "bluetooth", selected);
        addMediaSource(sources, "SPOTIFY", "spotify", selected);
        hub.addView(sources, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView active = label(getMediaSourceDescription(selected), 11, WHITE, true);
        active.setTag("media_source_description");
        hub.addView(active, new LinearLayout.LayoutParams(-1, dp(22)));

        LinearLayout controls = row();
        controls.setPadding(0, dp(7), 0, 0);
        addTransportButton(controls, "PREV", android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS);
        addTransportButton(controls, "PLAY / PAUSE", android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
        addTransportButton(controls, "NEXT", android.view.KeyEvent.KEYCODE_MEDIA_NEXT);
        TextView open = label("OPEN  ›", 10, BG, true);
        open.setGravity(Gravity.CENTER);
        open.setPadding(dp(12), 0, dp(12), 0);
        open.setBackground(panel(CYAN, CYAN, 10));
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-2, dp(38));
        openParams.leftMargin = dp(6);
        controls.addView(open, openParams);
        open.setOnClickListener(v -> launchSelectedMediaSource());
        hub.addView(controls);
        parent.addView(hub, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addMediaSource(LinearLayout parent, String title, String key, String selected) {
        boolean active = key.equals(selected);
        TextView chip = label(title, 9, active ? BG : WHITE, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(8), dp(7), dp(8), dp(7));
        chip.setBackground(panel(active ? CYAN : Color.rgb(17, 35, 50), active ? CYAN : LINE, 9));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(34), 1);
        p.setMargins(dp(2), 0, dp(2), 0);
        parent.addView(chip, p);
        chip.setOnClickListener(v -> {
            prefs.edit().putString("last_media_source", key).apply();
            if (mapMode) buildMapMode(); else buildHome();
        });
    }

    private String getMediaSourceDescription(String source) {
        if ("bluetooth".equals(source)) return "BLUETOOTH AUDIO  ·  ANDROID OUTPUT ROUTE";
        if ("spotify".equals(source)) return "SPOTIFY  ·  SELECTED PLAYER";
        return "LOCAL PLAYER  ·  SELECTED PLAYER";
    }

    private void addTransportButton(LinearLayout parent, String title, int keyCode) {
        TextView button = label(title, 9, WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(7), 0, dp(7), 0);
        button.setBackground(panel(Color.rgb(12, 26, 38), LINE, 9));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), title.equals("PLAY / PAUSE") ? 1.35f : 0.8f);
        p.setMargins(dp(2), 0, dp(2), 0);
        parent.addView(button, p);
        button.setOnClickListener(v -> dispatchMediaKey(keyCode));
    }

    private void dispatchMediaKey(int keyCode) {
        try {
            AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audio == null) return;
            long now = System.currentTimeMillis();
            audio.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, keyCode, 0));
            audio.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now + 1, android.view.KeyEvent.ACTION_UP, keyCode, 0));
        } catch (RuntimeException ex) {
            Toast.makeText(this, "No active media session is responding", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchSelectedMediaSource() {
        String source = prefs.getString("last_media_source", "local");
        String packageName;
        if ("spotify".equals(source)) {
            packageName = prefs.getString("spotify_package", "com.spotify.music");
            launchPackageOrFind(packageName, "spotify", "Spotify");
        } else {
            packageName = prefs.getString("local_media_package", "");
            if (packageName.length() == 0) {
                Toast.makeText(this, "Choose a local media player in Settings", Toast.LENGTH_LONG).show();
                showSettings();
                return;
            }
            if ("bluetooth".equals(source)) {
                prefs.edit().putString("last_media_source", "bluetooth").apply();
                Toast.makeText(this, "Bluetooth audio is controlled by your connected device. Opening your selected player.", Toast.LENGTH_LONG).show();
            }
            launchPackageOrFind(packageName, packageName, appNameSafe(packageName));
        }
    }

    private void buildHome() {
        mapMode = false;
        LinearLayout page = column();
        page.setPadding(dp(20), dp(10), dp(20), dp(8));
        setPage(page);
        addDashboardHeader(page, "NEO//DASH", "DRIVE INTERFACE");

        LinearLayout main = row();
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(-1, 0, 1);
        mainParams.topMargin = dp(8);
        mainParams.bottomMargin = dp(8);
        page.addView(main, mainParams);

        LinearLayout left = buildClockMediaPane();
        main.addView(left, new LinearLayout.LayoutParams(0, -1, 1.05f));

        LinearLayout right = column();
        right.setPadding(dp(13), dp(12), dp(10), dp(10));
        right.setBackground(panel(Color.rgb(10, 19, 29), Color.rgb(32, 113, 161), 18));
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, -1, 0.95f);
        rightParams.leftMargin = dp(12);
        main.addView(right, rightParams);

        LinearLayout titleRow = row();
        titleRow.addView(label("QUICK ACCESS", 11, CYAN, true));
        View gap = new View(this);
        titleRow.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView edit = label("EDIT", 9, WHITE, true);
        edit.setGravity(Gravity.CENTER);
        edit.setPadding(dp(9), dp(5), dp(9), dp(5));
        edit.setBackground(panel(PANEL_HI, LINE, 8));
        titleRow.addView(edit);
        edit.setOnClickListener(v -> chooseQuickLaunchApps());
        right.addView(titleRow, new LinearLayout.LayoutParams(-1, dp(26)));

        LinearLayout content = row();
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(-1, 0, 1);
        contentParams.topMargin = dp(8);
        right.addView(content, contentParams);
        LinearLayout grid = column();
        content.addView(grid, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout row1 = row();
        LinearLayout row2 = row();
        grid.addView(row1, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(-1, 0, 1);
        r2.topMargin = dp(8);
        grid.addView(row2, r2);

        ArrayList<ResolveInfo> shortcuts = selectedQuickLaunchApps();
        int pageCount = Math.max(1, (shortcuts.size() + 3) / 4);
        if (shortcutPage >= pageCount) shortcutPage = 0;
        for (int i = 0; i < 4; i++) {
            int actual = shortcutPage * 4 + i;
            LinearLayout target = i < 2 ? row1 : row2;
            if (actual < shortcuts.size()) {
                ResolveInfo info = shortcuts.get(actual);
                String name = info.loadLabel(getPackageManager()).toString();
                String pkg = info.activityInfo.packageName;
                addShortcut(target, name, pkg, name, i == 0);
            } else addChooseAppTile(target);
        }

        LinearLayout pager = column();
        pager.setGravity(Gravity.CENTER);
        TextView arrow = label("›", 34, CYAN, true);
        arrow.setGravity(Gravity.CENTER);
        arrow.setBackground(panel(Color.rgb(14, 34, 49), Color.rgb(31, 133, 183), 12));
        pager.addView(arrow, new LinearLayout.LayoutParams(dp(42), 0, 1));
        TextView pageLabel = label((shortcutPage + 1) + " / " + pageCount, 8, MUTED, true);
        pageLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pageLabelParams = new LinearLayout.LayoutParams(-1, dp(22));
        pageLabelParams.topMargin = dp(5);
        pager.addView(pageLabel, pageLabelParams);
        LinearLayout.LayoutParams pagerParams = new LinearLayout.LayoutParams(dp(46), -1);
        pagerParams.leftMargin = dp(6);
        content.addView(pager, pagerParams);
        arrow.setContentDescription("Next shortcuts page");
        arrow.setOnClickListener(v -> {
            shortcutPage = (shortcutPage + 1) % pageCount;
            prefs.edit().putInt("shortcut_page", shortcutPage).apply();
            buildHome();
        });
        addFooter(page, 0);
        updateClock();
    }

    private void addDashboardHeader(LinearLayout page, String brand, String subtitle) {
        LinearLayout header = row();
        TextView neo = label(brand, 24, WHITE, true);
        header.addView(neo);
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView ready = label(subtitle + "   /   SYSTEM READY", 9, CYAN, true);
        ready.setGravity(Gravity.CENTER);
        ready.setPadding(dp(10), dp(7), dp(10), dp(7));
        ready.setBackground(panel(Color.rgb(9, 29, 44), Color.rgb(28, 110, 154), 16));
        header.addView(ready);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(44)));
    }

    private void buildMapMode() {
        mapMode = true;
        LinearLayout page = column();
        page.setPadding(dp(20), dp(10), dp(20), dp(8));
        setPage(page);
        addDashboardHeader(page, "NEO//NAV", "MAP INTERFACE");
        LinearLayout main = row();
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, 0, 1);
        mp.topMargin = dp(8);
        mp.bottomMargin = dp(8);
        page.addView(main, mp);

        LinearLayout mapPane = column();
        mapPane.setPadding(dp(10), dp(9), dp(10), dp(9));
        mapPane.setBackground(panel(PANEL, Color.rgb(32, 113, 161), 18));
        main.addView(mapPane, new LinearLayout.LayoutParams(0, -1, 1.15f));
        LinearLayout mapHeader = row();
        mapHeader.addView(label("LIVE MAP VIEW", 11, CYAN, true));
        View mapGap = new View(this);
        mapHeader.addView(mapGap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView openMap = label("OPEN NAV APP  ↗", 9, WHITE, true);
        openMap.setPadding(dp(9), dp(6), dp(9), dp(6));
        openMap.setBackground(panel(PANEL_HI, LINE, 8));
        mapHeader.addView(openMap);
        openMap.setOnClickListener(v -> launchConfiguredMapApp());
        mapPane.addView(mapHeader, new LinearLayout.LayoutParams(-1, dp(34)));

        try {
            mapWebView = new WebView(this);
            mapWebView.setBackgroundColor(Color.rgb(8, 16, 23));
            WebSettings settings = mapWebView.getSettings();
            settings.setJavaScriptEnabled(false);
            settings.setDomStorageEnabled(false);
            settings.setSupportZoom(true);
            mapPane.addView(mapWebView, new LinearLayout.LayoutParams(-1, 0, 1));
            mapWebView.loadUrl(buildEmbeddedMapUrl());
        } catch (RuntimeException ex) {
            mapPane.addView(label("Embedded map is unavailable on this Android WebView. Use OPEN NAV APP.", 12, MUTED, false));
        }
        TextView mapNote = label("MAP PANEL: OpenStreetMap  ·  NAVIGATION: YOUR SELECTED APP", 8, MUTED, false);
        LinearLayout.LayoutParams mn = new LinearLayout.LayoutParams(-1, dp(20));
        mn.topMargin = dp(4);
        mapPane.addView(mapNote, mn);

        LinearLayout right = buildClockMediaPane();
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, -1, 0.85f);
        rightParams.leftMargin = dp(12);
        main.addView(right, rightParams);
        addFooter(page, 1);
        updateClock();
    }

    private String buildEmbeddedMapUrl() {
        double lat = Double.NaN;
        double lon = Double.NaN;
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm != null && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Location gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Location net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                Location best = gps != null ? gps : net;
                if (gps != null && net != null && net.getTime() > gps.getTime()) best = net;
                if (best != null) { lat = best.getLatitude(); lon = best.getLongitude(); }
            }
        } catch (RuntimeException ignored) { }
        if (Double.isNaN(lat) || Double.isNaN(lon)) {
            return "https://www.openstreetmap.org";
        }
        mapLatitude = lat;
        mapLongitude = lon;
        double deltaLat = 0.025;
        double deltaLon = 0.035;
        return "https://www.openstreetmap.org/export/embed.html?bbox="
                + (lon - deltaLon) + "%2C" + (lat - deltaLat) + "%2C" + (lon + deltaLon) + "%2C" + (lat + deltaLat)
                + "&layer=mapnik&marker=" + lat + "%2C" + lon;
    }

    private void launchConfiguredMapApp() {
        String pkg = prefs.getString("map_package", "");
        if (pkg.length() == 0) { Toast.makeText(this, "Select a map app in Settings", Toast.LENGTH_LONG).show(); showSettings(); return; }
        if (Double.isNaN(mapLatitude) || Double.isNaN(mapLongitude)) buildEmbeddedMapUrl();
        Intent launch = null;
        if (!Double.isNaN(mapLatitude) && !Double.isNaN(mapLongitude)) {
            Uri location = Uri.parse("geo:" + mapLatitude + "," + mapLongitude + "?q=" + mapLatitude + "," + mapLongitude);
            launch = new Intent(Intent.ACTION_VIEW, location);
            launch.setPackage(pkg);
            if (launch.resolveActivity(getPackageManager()) == null) launch = null;
        }
        if (launch == null) launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            try { startActivity(launch); } catch (RuntimeException ex) { Toast.makeText(this, "Unable to open the selected map app", Toast.LENGTH_SHORT).show(); }
        } else Toast.makeText(this, "Selected map app is no longer installed", Toast.LENGTH_LONG).show();
    }

    private void showPermissionSetup() {
        setupUiVisible = true;
        LinearLayout page = column();
        page.setPadding(dp(26), dp(20), dp(26), dp(18));
        setPage(page);
        page.addView(label("NEO//DASH", 28, WHITE, true));
        TextView title = label("INITIAL DEVICE SETUP", 14, CYAN, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(35));
        tp.topMargin = dp(6);
        page.addView(title, tp);
        TextView intro = label("Before opening the dashboard, NeoDash needs access to the device features selected for this installation. Grant each permission below.", 12, MUTED, false);
        intro.setPadding(0, dp(7), 0, dp(14));
        page.addView(intro);
        LinearLayout card = column();
        card.setPadding(dp(17), dp(13), dp(17), dp(13));
        card.setBackground(panel(PANEL, LINE, 18));
        addPermissionStatusRow(card, "LOCATION / GPS", Manifest.permission.ACCESS_FINE_LOCATION);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            addPermissionStatusRow(card, "NEARBY DEVICES / BLUETOOTH", Manifest.permission.BLUETOOTH_CONNECT);
            addPermissionStatusRow(card, "BLUETOOTH SCAN", Manifest.permission.BLUETOOTH_SCAN);
        } else addPermissionStatusRow(card, "BLUETOOTH", Manifest.permission.BLUETOOTH);
        if (android.os.Build.VERSION.SDK_INT >= 33) addPermissionStatusRow(card, "NOTIFICATIONS", Manifest.permission.POST_NOTIFICATIONS);
        page.addView(card, new LinearLayout.LayoutParams(-1, -2));
        TextView note = label("NeoDash will not start its connection monitor until the required permissions are granted. You can review them later in Settings.", 10, MUTED, false);
        note.setPadding(0, dp(12), 0, dp(12));
        page.addView(note);
        TextView grant = label(hasAllRequiredPermissions() ? "CONTINUE TO APP SETUP  ›" : "GRANT REQUIRED PERMISSIONS  ›", 12, BG, true);
        grant.setGravity(Gravity.CENTER);
        grant.setBackground(panel(CYAN, CYAN, 12));
        page.addView(grant, new LinearLayout.LayoutParams(-1, dp(50)));
        grant.setOnClickListener(v -> requestRequiredPermissions());
        if (!hasAllRequiredPermissions()) {
            TextView settings = label("OPEN ANDROID APP PERMISSIONS", 10, CYAN, true);
            settings.setGravity(Gravity.CENTER);
            settings.setPadding(0, dp(13), 0, dp(8));
            page.addView(settings);
            settings.setOnClickListener(v -> openAppPermissionSettings());
        }
    }

    private void addPermissionStatusRow(LinearLayout parent, String title, String permission) {
        boolean granted = permissionGranted(permission);
        LinearLayout row = row();
        TextView name = label(title, 11, WHITE, true);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(34), 1));
        TextView state = label(granted ? "GRANTED  ✓" : "REQUIRED", 9, granted ? CYAN : Color.rgb(255, 190, 92), true);
        state.setGravity(Gravity.CENTER);
        row.addView(state, new LinearLayout.LayoutParams(dp(94), dp(34)));
        parent.addView(row);
    }

    private boolean permissionGranted(String permission) {
        if (android.os.Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasAllRequiredPermissions() {
        if (!permissionGranted(Manifest.permission.ACCESS_FINE_LOCATION)) return false;
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (!permissionGranted(Manifest.permission.BLUETOOTH_CONNECT)) return false;
            if (!permissionGranted(Manifest.permission.BLUETOOTH_SCAN)) return false;
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && !permissionGranted(Manifest.permission.POST_NOTIFICATIONS)) return false;
        return true;
    }

    private void requestRequiredPermissions() {
        if (hasAllRequiredPermissions()) { showConfigurationWizard(); return; }
        ArrayList<String> missing = new ArrayList<>();
        if (!permissionGranted(Manifest.permission.ACCESS_FINE_LOCATION)) missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (!permissionGranted(Manifest.permission.BLUETOOTH_CONNECT)) missing.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (!permissionGranted(Manifest.permission.BLUETOOTH_SCAN)) missing.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && !permissionGranted(Manifest.permission.POST_NOTIFICATIONS)) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (missing.isEmpty()) { showConfigurationWizard(); return; }
        if (android.os.Build.VERSION.SDK_INT >= 23) requestPermissions(missing.toArray(new String[0]), REQUEST_SETUP_PERMISSIONS);
    }

    private void openAppPermissionSettings() {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (RuntimeException ex) { Toast.makeText(this, "Android app settings could not be opened", Toast.LENGTH_SHORT).show(); }
    }

    private void showConfigurationWizard() {
        setupUiVisible = true;
        LinearLayout page = column();
        page.setPadding(dp(25), dp(18), dp(25), dp(15));
        setPage(page);
        page.addView(label("NEO//DASH", 27, WHITE, true));
        page.addView(label("PERSONALIZE YOUR COCKPIT", 13, CYAN, true));
        TextView hint = label("Choose the installed apps NeoDash should use. These choices can be changed later in Settings.", 11, MUTED, false);
        hint.setPadding(0, dp(8), 0, dp(12));
        page.addView(hint);
        LinearLayout list = column();
        list.setPadding(dp(13), dp(10), dp(13), dp(10));
        list.setBackground(panel(PANEL, LINE, 18));
        addAppPreferenceRow(list, "DEFAULT MAP APPLICATION", "map_package", "Choose an installed map app", "map");
        addAppPreferenceRow(list, "iOS CARPLAY RECEIVER", "ios_app_package", "Choose the iOS receiver app", "ios");
        addAppPreferenceRow(list, "ANDROID AUTO RECEIVER", "android_app_package", "Choose the Android receiver app", "android");
        addAppPreferenceRow(list, "LOCAL MEDIA PLAYER", "local_media_package", "Choose your local music player", "media");
        page.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView finish = label("FINISH SETUP  ›", 12, BG, true);
        finish.setGravity(Gravity.CENTER);
        finish.setBackground(panel(CYAN, CYAN, 12));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(50));
        fp.topMargin = dp(12);
        page.addView(finish, fp);
        finish.setOnClickListener(v -> {
            String[] keys = {"map_package", "ios_app_package", "android_app_package", "local_media_package"};
            for (String key : keys) {
                if (prefs.getString(key, "").trim().length() == 0) {
                    Toast.makeText(this, "Select all four defaults before continuing", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            if (prefs.getString("spotify_package", "").length() == 0) {
                String spotify = findInstalledPackage("spotify");
                if (spotify != null) prefs.edit().putString("spotify_package", spotify).apply();
            }
            enterDashboard();
        });
    }

    private void addAppPreferenceRow(LinearLayout parent, String title, String key, String emptyText, String type) {
        LinearLayout item = column();
        item.setPadding(dp(3), dp(6), dp(3), dp(8));
        TextView heading = label(title, 10, CYAN, true);
        item.addView(heading);
        LinearLayout action = row();
        TextView current = label(prefs.getString(key, "").length() == 0 ? emptyText : appNameSafe(prefs.getString(key, "")), 11, WHITE, false);
        action.addView(current, new LinearLayout.LayoutParams(0, dp(40), 1));
        TextView choose = label("SELECT  ›", 9, BG, true);
        choose.setGravity(Gravity.CENTER);
        choose.setPadding(dp(10), 0, dp(10), 0);
        choose.setBackground(panel(CYAN, CYAN, 9));
        action.addView(choose, new LinearLayout.LayoutParams(-2, dp(36)));
        item.addView(action);
        item.setOnClickListener(v -> chooseInstalledApp(title, key, type, true));
        parent.addView(item);
        View line = new View(this);
        line.setBackgroundColor(LINE);
        parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private String findInstalledPackage(String hint) {
        for (ResolveInfo info : launchableApps()) {
            String label = info.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
            String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
            if (label.contains(hint) || pkg.contains(hint.replace(" ", ""))) return info.activityInfo.packageName;
        }
        return null;
    }

    private void chooseInstalledApp(String title, String prefKey, String type, boolean refreshSetup) {
        List<ResolveInfo> installed = launchableApps();
        ArrayList<ResolveInfo> matches = new ArrayList<>();
        for (ResolveInfo info : installed) {
            String label = info.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
            String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
            boolean match;
            if ("map".equals(type)) match = containsAny(label + " " + pkg, new String[]{"map", "waze", "navigation", "osmand", "here", "sygic", "tomtom", "mapfactor"});
            else if ("ios".equals(type)) match = containsAny(label + " " + pkg, new String[]{"diplay", "carplay", "airplay"});
            else if ("android".equals(type)) match = containsAny(label + " " + pkg, new String[]{"diauto", "android auto", "gearhead"});
            else if ("spotify".equals(type)) match = containsAny(label + " " + pkg, new String[]{"spotify"});
            else match = containsAny(label + " " + pkg, new String[]{"music", "audio", "player", "vlc", "poweramp", "foobar", "spotify"});
            if (match && !info.activityInfo.packageName.equals(getPackageName())) matches.add(info);
        }
        if (matches.isEmpty()) {
            for (ResolveInfo info : installed) if (!info.activityInfo.packageName.equals(getPackageName())) matches.add(info);
        }
        if (matches.isEmpty()) {
            Toast.makeText(this, "No selectable apps are installed", Toast.LENGTH_LONG).show();
            return;
        }
        String[] labels = new String[matches.size()];
        for (int i = 0; i < matches.size(); i++) labels[i] = matches.get(i).loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this).setTitle(title).setItems(labels, (dialog, which) -> {
            String pkg = matches.get(which).activityInfo.packageName;
            prefs.edit().putString(prefKey, pkg).apply();
            if ("spotify".equals(type)) prefs.edit().putString("spotify_package", pkg).apply();
            if (refreshSetup) showConfigurationWizard(); else showSettings();
        }).setNegativeButton("CANCEL", null).show();
    }

    private boolean containsAny(String value, String[] tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }

    private void launchMobileForDetectedPhone() {
        SharedPreferences connection = getSharedPreferences("neodash_connection", MODE_PRIVATE);
        if (!connection.getBoolean("receiver_active", false)) {
            Toast.makeText(this, "No compatible phone session has been detected yet", Toast.LENGTH_LONG).show();
            return;
        }
        String os = connection.getString("device_os", "");
        String session = connection.getString("session_id", "");
        String already = connection.getString("autolaunched_session", "");
        if (session.equals(already) || connection.getBoolean("receiver_running", false)) {
            Toast.makeText(this, "The connected phone receiver is already active", Toast.LENGTH_SHORT).show();
            return;
        }
        String pkg = "ios".equalsIgnoreCase(os)
                ? prefs.getString("ios_app_package", "") : prefs.getString("android_app_package", "");
        if (pkg.length() == 0) {
            Toast.makeText(this, "Select your iOS and Android receiver apps in Settings", Toast.LENGTH_LONG).show();
            return;
        }
        connection.edit().putString("autolaunched_session", session).apply();
        launchPackageOrFind(pkg, pkg, appNameSafe(pkg));
    }

'''
java = replace_method(java, "    private void buildHome()", "    private void addShortcut(", build_and_helpers)

# The user's chosen paging behavior allows eight shortcuts over two pages, with a permanent arrow.
java = java.replace('if (result.size() == 4) break;', 'if (result.size() == 8) break;', 1)
java = java.replace('.setTitle("Choose up to 4 apps")', '.setTitle("Choose up to 8 apps · 4 per page")', 1)
java = java.replace('if (selected.size() >= 4) {', 'if (selected.size() >= 8) {', 1)
java = java.replace('Toast.makeText(this, "Choose up to 4 apps", Toast.LENGTH_SHORT).show();', 'Toast.makeText(this, "Choose up to 8 apps", Toast.LENGTH_SHORT).show();', 1)

# Settings: all defaults are editable here as well as during first launch.
settings_method = r'''    private void showSettings() {
        LinearLayout page = column();
        page.setPadding(dp(22), dp(15), dp(22), dp(10));
        setPage(page);
        LinearLayout header = row();
        header.addView(label("SYSTEM CONFIGURATION", 21, WHITE, true));
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView back = label("HOME  ‹", 10, CYAN, true);
        header.addView(back);
        back.setOnClickListener(v -> buildHome());
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(40)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = column();
        body.setPadding(dp(16), dp(13), dp(16), dp(14));
        body.setBackground(panel(PANEL, LINE, 17));
        scroll.addView(body);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        body.addView(label("APP DEFAULTS", 11, CYAN, true));
        addAppPreferenceRow(body, "DEFAULT MAP APPLICATION", "map_package", "Not selected", "map");
        addAppPreferenceRow(body, "iOS CARPLAY RECEIVER", "ios_app_package", "Not selected", "ios");
        addAppPreferenceRow(body, "ANDROID AUTO RECEIVER", "android_app_package", "Not selected", "android");
        addAppPreferenceRow(body, "LOCAL MEDIA PLAYER", "local_media_package", "Not selected", "media");
        addAppPreferenceRow(body, "SPOTIFY APPLICATION", "spotify_package", "Find Spotify", "spotify");

        TextView sourceHeading = label("MEDIA SOURCE", 11, CYAN, true);
        LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(-1, dp(27));
        sh.topMargin = dp(12);
        body.addView(sourceHeading, sh);
        LinearLayout sources = row();
        String selected = prefs.getString("last_media_source", "local");
        addSettingChoice(sources, "LOCAL", "local".equals(selected), () -> { prefs.edit().putString("last_media_source", "local").apply(); showSettings(); });
        addSettingChoice(sources, "BLUETOOTH", "bluetooth".equals(selected), () -> { prefs.edit().putString("last_media_source", "bluetooth").apply(); showSettings(); });
        addSettingChoice(sources, "SPOTIFY", "spotify".equals(selected), () -> { prefs.edit().putString("last_media_source", "spotify").apply(); showSettings(); });
        body.addView(sources, new LinearLayout.LayoutParams(-1, dp(48)));
        body.addView(label("NeoDash remembers the last media source you select.", 10, MUTED, false));

        TextView perms = label("PERMISSIONS", 11, CYAN, true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(28));
        pp.topMargin = dp(12);
        body.addView(perms, pp);
        addPermissionStatusRow(body, "LOCATION / GPS", Manifest.permission.ACCESS_FINE_LOCATION);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            addPermissionStatusRow(body, "NEARBY DEVICES", Manifest.permission.BLUETOOTH_CONNECT);
            addPermissionStatusRow(body, "BLUETOOTH SCAN", Manifest.permission.BLUETOOTH_SCAN);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) addPermissionStatusRow(body, "NOTIFICATIONS", Manifest.permission.POST_NOTIFICATIONS);
        TextView permissionSettings = label("MANAGE ANDROID PERMISSIONS  ›", 10, CYAN, true);
        permissionSettings.setPadding(0, dp(8), 0, dp(8));
        body.addView(permissionSettings);
        permissionSettings.setOnClickListener(v -> openAppPermissionSettings());

        body.addView(label("ICON APPEARANCE", 11, CYAN, true));
        body.addView(label("Blue chrome is the primary interface finish. Yellow, magenta and cyan remain restrained secondary accents.", 10, MUTED, false));
        LinearLayout styles = row();
        styles.setPadding(0, dp(9), 0, dp(12));
        addSettingChoice(styles, "NEON CHROME", neon, () -> { neon = true; prefs.edit().putBoolean("neon", true).apply(); showSettings(); });
        addSettingChoice(styles, "STANDARD", !neon, () -> { neon = false; prefs.edit().putBoolean("neon", false).apply(); showSettings(); });
        body.addView(styles);

        body.addView(label("ICON SIZE", 11, CYAN, true));
        LinearLayout sizes = row();
        sizes.setPadding(0, dp(8), 0, dp(12));
        addSettingChoice(sizes, "COMPACT", iconScale == 0, () -> setIconScale(0));
        addSettingChoice(sizes, "COMFORT", iconScale == 1, () -> setIconScale(1));
        addSettingChoice(sizes, "LARGE", iconScale == 2, () -> setIconScale(2));
        body.addView(sizes);

        TextView services = label("DEVICE SERVICES", 11, CYAN, true);
        LinearLayout.LayoutParams serviceHeadingParams = new LinearLayout.LayoutParams(-1, dp(24));
        serviceHeadingParams.topMargin = dp(10);
        body.addView(services, serviceHeadingParams);
        TextView serviceStatus = label(getSystemStatusText(), 11, MUTED, false);
        serviceStatus.setTag("system_service_status");
        body.addView(serviceStatus);
        body.addView(label("TIME SYNCHRONIZATION", 11, CYAN, true));
        TextView timeSyncStatus = label(getTimeSyncStatusText(), 11, MUTED, false);
        timeSyncStatus.setTag("time_sync_status");
        body.addView(timeSyncStatus);
        physicalKeyStatusView = label(getLastPhysicalKeyText(), 11, MUTED, false);
        physicalKeyStatusView.setTag("physical_key_status");
        body.addView(label("PHYSICAL BUTTON INPUT", 11, CYAN, true));
        body.addView(physicalKeyStatusView);
        body.addView(label("D-pad, OK, Back and Menu keys are supported. Media transport keys are passed to Android's active media session.", 10, MUTED, false));

        LinearLayout links = row();
        addSystemShortcut(links, "DATE / TIME", Settings.ACTION_DATE_SETTINGS);
        addSystemShortcut(links, "LOCATION", Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        addSystemShortcut(links, "BLUETOOTH", Settings.ACTION_BLUETOOTH_SETTINGS);
        addSystemShortcut(links, "WI-FI", Settings.ACTION_WIFI_SETTINGS);
        body.addView(links);
        body.addView(label("NEODASH 0.3.2  ·  BLUE CHROME COCKPIT", 9, MUTED, true));
        addFooter(page, 5);
    }
'''
java = replace_method(java, "    private void showSettings()", "    private String getSystemStatusText()", settings_method)

# Footer includes Map and Mobile; Mobile uses the configured phone receiver and no chooser prompt.
footer_method = r'''    private void addFooter(LinearLayout page, int selected) {
        LinearLayout footer = row();
        footer.setPadding(dp(2), dp(3), dp(2), 0);
        String[] labels = {"HOME", "MAP", "MOBILE", "SWITCH", "APPS", "SETTINGS"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            boolean emphasized = index == 2;
            TextView item = label(labels[i], 9, emphasized ? BG : (selected == i ? CYAN : MUTED), true);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(9), dp(4), dp(9));
            if (emphasized) item.setBackground(panel(CYAN, CYAN, 13));
            else if (selected == i) item.setBackground(panel(Color.rgb(9, 31, 47), Color.rgb(31, 112, 155), 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            footer.addView(item, lp);
            item.setMinimumHeight(dp(46));
            item.setContentDescription(labels[i]);
            item.setOnClickListener(v -> {
                if (index == 0) buildHome();
                else if (index == 1) buildMapMode();
                else if (index == 2) launchMobileForDetectedPhone();
                else if (index == 3) showAppSwitcher();
                else if (index == 4) showApps();
                else showSettings();
            });
        }
        page.addView(footer, new LinearLayout.LayoutParams(-1, dp(48)));
    }
'''
java = replace_method(java, "    private void addFooter(LinearLayout page, int selected)", "    private long getVerifiedDashboardTimeMillis()", footer_method)

# No automatic connection-monitor calls until setup and permissions are complete.
java = java.replace('''        Intent timeRefresh = new Intent(this, NeoDashConnectionManager.class);
        timeRefresh.setAction(NeoDashConnectionManager.ACTION_REFRESH_TIME);
        try { startService(timeRefresh); } catch (RuntimeException ignored) { }
''', '''        if (prefs != null && prefs.getBoolean(PREF_SETUP_COMPLETE, false) && hasAllRequiredPermissions()) {
            Intent timeRefresh = new Intent(this, NeoDashConnectionManager.class);
            timeRefresh.setAction(NeoDashConnectionManager.ACTION_REFRESH_TIME);
            try { startService(timeRefresh); } catch (RuntimeException ignored) { }
        }
''', 1)
# Gate all onResume work while onboarding is incomplete.
needle = '''    @Override protected void onResume() {
        super.onResume();
'''
replacement = '''    @Override protected void onResume() {
        super.onResume();
        if (prefs != null && !prefs.getBoolean(PREF_SETUP_COMPLETE, false)) {
            if (hasAllRequiredPermissions()) showConfigurationWizard();
            else if (!setupUiVisible) showPermissionSetup();
            return;
        }
        if (prefs != null && !hasAllRequiredPermissions()) { showPermissionSetup(); return; }
'''
if needle not in java: raise SystemExit("onResume insertion point missing")
java = java.replace(needle, replacement, 1)
# Add receiver-session events to the same registered filter and launch configured app silently.
needle = '            statusFilter.addAction(NeoDashTimeSyncManager.ACTION_TIME_STATUS);'
java = java.replace(needle, needle + '\n            statusFilter.addAction(NeoDashConnectionManager.ACTION_RECEIVER_SESSION);', 1)
needle = '''                    if (inputStatus instanceof TextView) ((TextView) inputStatus).setText(getLastPhysicalKeyText());
'''
java = java.replace(needle, needle + '''                    if (NeoDashConnectionManager.ACTION_RECEIVER_SESSION.equals(intent.getAction())) showPendingReceiverPrompt();
''', 1)

pending_method = '''    private void showPendingReceiverPrompt() {
        SharedPreferences connection = getSharedPreferences("neodash_connection", MODE_PRIVATE);
        if (!connection.getBoolean("receiver_active", false)) return;
        String session = connection.getString("session_id", null);
        if (session == null || session.equals(connection.getString("autolaunched_session", null))) return;
        if (connection.getBoolean("receiver_running", false)) return;
        launchMobileForDetectedPhone();
    }
'''
java = replace_method(java, "    private void showPendingReceiverPrompt()", "    private View findViewWithTag(", pending_method)

# Request permission results: do not enter the dashboard unless every required permission is granted.
permission_result = '''    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_SETUP_PERMISSIONS) return;
        if (hasAllRequiredPermissions()) showConfigurationWizard();
        else {
            Toast.makeText(this, "NeoDash needs the selected permissions before setup can continue", Toast.LENGTH_LONG).show();
            showPermissionSetup();
        }
    }

'''
insert_point = '    private void showPendingReceiverPrompt() {'
if insert_point not in java: raise SystemExit("permission result insertion point missing")
java = java.replace(insert_point, permission_result + insert_point, 1)

# The app switcher remains in the same section, but settings now exposes the Mobile receiver app choices.
# Remove obsolete prompt text and fix selected footer index on app switcher/apps pages where applicable.
java = java.replace('        addFooter(page, 1);\n', '        addFooter(page, 3);\n')
# Map is bottom-nav item 1; app switcher is item 3; installed apps is item 4.
map_start = java.find("    private void buildMapMode()")
map_end = java.find("    private String buildEmbeddedMapUrl()", map_start)
if map_start >= 0 and map_end >= 0:
    section = java[map_start:map_end].replace("addFooter(page, 3);", "addFooter(page, 1);")
    java = java[:map_start] + section + java[map_end:]
apps_start = java.find("    private void showApps()")
apps_end = java.find("    private void showSettings()", apps_start)
if apps_start >= 0 and apps_end >= 0:
    section = java[apps_start:apps_end].replace("addFooter(page, 3);", "addFooter(page, 4);")
    java = java[:apps_start] + section + java[apps_end:]

# Add manifest runtime permissions and ensure service is not started at boot before setup is complete.
if 'android.permission.BLUETOOTH_CONNECT' not in manifest:
    manifest = manifest.replace('    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />', '''    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />''', 1)
# Old Bluetooth permissions apply only through Android 11; Android 12+ uses Nearby Devices.
manifest = manifest.replace('android:name="android.permission.BLUETOOTH" />', 'android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />')
manifest = manifest.replace('android:name="android.permission.BLUETOOTH_ADMIN" />', 'android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />')
# Keep the existing service FGS location type, but grant runtime location before startup.

# target 32 enables runtime Nearby Devices permissions while avoiding Android 14 target-34 FGS policy changes.
gradle = re.sub(r'targetSdk\s+\d+', 'targetSdk 33', gradle)
gradle = gradle.replace('versionCode 5', 'versionCode 6').replace("versionName '0.3.1-chrome-neon-icons'", "versionName '0.3.2-cyberpunk-dashboard'")
gradle = gradle.replace("applicationIdSuffix '.debug31'", "applicationIdSuffix '.debug32'")
if "versionName '0.3.2-cyberpunk-dashboard'" not in gradle:
    # Supports baseline builds where patch_chrome_neon.py hasn't been applied to app/build.gradle yet.
    gradle = gradle.replace("versionName '0.3.0-time-input-foundation'", "versionName '0.3.2-cyberpunk-dashboard'")
    gradle = gradle.replace('versionCode 4', 'versionCode 6')
    gradle = gradle.replace("applicationIdSuffix '.debug'", "applicationIdSuffix '.debug32'")

# Do not resurrect the foreground location service during boot before first-run setup and grants.
boot_path = project / "app/src/main/java/com/neodash/launcher/NeoDashBootReceiver.java"
if boot_path.exists():
    boot_path.write_text(r'''package com.neodash.launcher;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

/** Starts the connection monitor only after onboarding and required permissions are complete. */
public final class NeoDashBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;
        SharedPreferences prefs = context.getSharedPreferences("neodash", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("setup_complete", false)) return;
        if (Build.VERSION.SDK_INT >= 23
                && context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 31) {
            if (context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
            if (context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        // MainActivity starts the location-type monitor while visible after permissions are granted.
        // Do not create a location foreground service directly from BOOT_COMPLETED in the background.
    }
}
''', encoding="utf-8")

# Update local README/version references in the generated project.
readme_path = project / "README.md"
if readme_path.exists():
    readme = readme_path.read_text(encoding="utf-8")
    readme = readme.replace("NeoDash 0.3.1", "NeoDash 0.3.2")
    readme = readme.replace("Chrome + Neon", "Blue Chrome Cyberpunk")
    readme_path.write_text(readme, encoding="utf-8")

java_path.write_text(java, encoding="utf-8")
manifest_path.write_text(manifest, encoding="utf-8")
gradle_path.write_text(gradle, encoding="utf-8")
print("Applied NeoDash 0.3.2 permission onboarding, app defaults, media sources, map pane and dual-panel dashboard.")
