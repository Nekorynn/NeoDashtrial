package com.neodash.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.InputDevice;
import android.view.ViewGroup;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Locale;

/**
 * NeoDash 0.3.0 - Time synchronization and physical input foundation.
 * Lightweight native Android Views; no media decoder, network service or vehicle-data claims.
 */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(16, 18, 21);
    private static final int PANEL = Color.rgb(25, 29, 33);
    private static final int PANEL_HI = Color.rgb(33, 39, 44);
    private static final int BLUE = Color.rgb(22, 139, 255);
    private static final int CYAN = Color.rgb(0, 217, 255);
    private static final int MUTED = Color.rgb(144, 160, 182);
    private static final int WHITE = Color.rgb(239, 246, 255);
    private static final int LINE = Color.rgb(55, 67, 73);

    private LinearLayout root;
    private TextView clockView, dateView, timeStatusView, physicalKeyStatusView;
    private ProgressBar timeProgress;
    private BroadcastReceiver timeReceiver;
    private BroadcastReceiver statusReceiver;
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockTicker = new Runnable() {
        @Override public void run() {
            updateClock();
            if (!isFinishing()) clockHandler.postDelayed(this, 1000L);
        }
    };
    private List<ResolveInfo> cachedLaunchableApps;
    private SharedPreferences prefs;
    private boolean neon = true;
    private int iconScale = 1; // 0 compact, 1 comfort, 2 large
    private final ArrayList<String> recentPackages = new ArrayList<>();
    private static final String DASHBOARD_TIME_ZONE = "Asia/Manila";

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("neodash", MODE_PRIVATE);
        neon = prefs.getBoolean("neon", true);
        iconScale = prefs.getInt("icon_scale", 1);
        Set<String> savedRecent = prefs.getStringSet("recent_packages", new LinkedHashSet<String>());
        if (savedRecent != null) recentPackages.addAll(savedRecent);
        applyImmersiveMode();
        buildHome();
        Intent monitor = new Intent(this, NeoDashConnectionManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(monitor);
        else startService(monitor);
    }

    private void applyImmersiveMode() {
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable panel(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{fill, Color.rgb(Math.max(0, Color.red(fill) - 2),
                        Math.max(0, Color.green(fill) - 2), Math.max(0, Color.blue(fill) - 2))});
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        else v.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    private LinearLayout row() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private void setPage(LinearLayout page) {
        root = page;
        root.setBackgroundColor(BG);
        root.setFocusable(true);
        root.setFocusableInTouchMode(false);
        root.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        setContentView(root);
        LinearLayout pageRoot = root;
        pageRoot.post(() -> {
            enableHardwareFocus(pageRoot);
            if (pageRoot.findFocus() == null) pageRoot.requestFocus();
        });
    }

    private void enableHardwareFocus(View view) {
        if (view.isClickable() || view.isLongClickable()) {
            view.setFocusable(true);
            view.setFocusableInTouchMode(false);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) enableHardwareFocus(group.getChildAt(i));
        }
    }

    private void buildHome() {
        LinearLayout page = column();
        page.setPadding(dp(20), dp(10), dp(20), dp(8));
        setPage(page);

        // Compact brand header; no fake GPS or vehicle telemetry status.
        LinearLayout header = row();
        TextView neo = label("NEO", 25, WHITE, true);
        TextView dash = label("DASH", 25, CYAN, true);
        header.addView(neo);
        header.addView(dash);
        TextView sub = label("   DRIVE INTERFACE", 10, MUTED, true);
        header.addView(sub);
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView ready = label("●  READY", 11, CYAN, true);
        ready.setPadding(dp(12), dp(7), dp(12), dp(7));
        ready.setBackground(panel(Color.rgb(10, 31, 45), Color.rgb(0, 91, 128), 20));
        header.addView(ready);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(44)));

        LinearLayout main = row();
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(-1, 0, 1);
        mainParams.topMargin = dp(8);
        mainParams.bottomMargin = dp(8);
        page.addView(main, mainParams);

        // Left side: time and the existing head-unit media app shortcut.
        LinearLayout left = column();
        left.setPadding(dp(18), dp(14), dp(18), dp(12));
        left.setBackground(panel(PANEL, LINE, 18));
        main.addView(left, new LinearLayout.LayoutParams(0, -1, 1.15f));

        // Fixed line height keeps the large clock readable on short head-unit displays.
        clockView = label("--:--", 56, WHITE, true);
        clockView.setSingleLine(true);
        clockView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        clockView.setLetterSpacing(-0.02f);
        LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(-1, dp(72));
        clockParams.topMargin = dp(1);
        left.addView(clockView, clockParams);
        dateView = label("VERIFYING DATE & TIME", 14, MUTED, false);
        left.addView(dateView);
        timeProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        timeProgress.setIndeterminate(true);
        timeProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(CYAN));
        LinearLayout.LayoutParams timeProgressParams = new LinearLayout.LayoutParams(dp(190), dp(5));
        timeProgressParams.topMargin = dp(10);
        left.addView(timeProgress, timeProgressParams);
        timeStatusView = label("Checking network, satellite and system time...", 10, MUTED, false);
        LinearLayout.LayoutParams timeStatusParams = new LinearLayout.LayoutParams(-1, dp(24));
        timeStatusParams.topMargin = dp(3);
        left.addView(timeStatusView, timeStatusParams);

        View line = new View(this);
        line.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(-1, dp(1));
        lineParams.topMargin = dp(12);
        lineParams.bottomMargin = dp(10);
        left.addView(line, lineParams);

        LinearLayout media = row();
        media.setPadding(dp(12), dp(8), dp(12), dp(8));
        media.setBackground(panel(PANEL_HI, Color.rgb(34, 78, 111), 15));
        TextView musicIcon = label("♫", 29, CYAN, true);
        musicIcon.setGravity(Gravity.CENTER);
        media.addView(musicIcon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout mediaText = column();
        mediaText.setPadding(dp(10), 0, 0, 0);
        mediaText.addView(label("MEDIA", 13, WHITE, true));
        mediaText.addView(label("Open your existing player", 10, MUTED, false));
        media.addView(mediaText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView openMedia = label("OPEN  ›", 11, CYAN, true);
        media.addView(openMedia);
        media.setOnClickListener(v -> launchExistingMedia());
        left.addView(media, new LinearLayout.LayoutParams(-1, dp(60)));

        // Right side: four large, touch-friendly shortcuts.
        LinearLayout right = column();
        right.setPadding(dp(14), dp(12), dp(14), dp(10));
        right.setBackground(panel(Color.rgb(21, 25, 29), Color.rgb(0, 100, 120), 18));
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, -1, 0.9f);
        rightParams.leftMargin = dp(14);
        main.addView(right, rightParams);

        LinearLayout shortcutHeading = row();
        TextView editShortcuts = label("EDIT APPS", 10, CYAN, true);
        shortcutHeading.addView(editShortcuts);
        editShortcuts.setOnClickListener(v -> chooseQuickLaunchApps());
        View headingGap = new View(this);
        shortcutHeading.addView(headingGap, new LinearLayout.LayoutParams(0, 1, 1));
        shortcutHeading.addView(label("UP TO 4", 9, MUTED, true));
        right.addView(shortcutHeading, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout gridRow1 = row();
        LinearLayout gridRow2 = row();
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(-1, 0, 1);
        gridParams.topMargin = dp(11);
        right.addView(gridRow1, gridParams);
        LinearLayout.LayoutParams gridParams2 = new LinearLayout.LayoutParams(-1, 0, 1);
        gridParams2.topMargin = dp(9);
        right.addView(gridRow2, gridParams2);

        ArrayList<ResolveInfo> shortcuts = selectedQuickLaunchApps();
        for (int i = 0; i < 4; i++) {
            LinearLayout target = i < 2 ? gridRow1 : gridRow2;
            if (i < shortcuts.size()) {
                ResolveInfo info = shortcuts.get(i);
                String name = info.loadLabel(getPackageManager()).toString();
                String pkg = info.activityInfo.packageName;
                addShortcut(target, name, pkg, name, i == 0);
            } else {
                addChooseAppTile(target);
            }
        }

        addFooter(page, 0);
    }

    private void addShortcut(LinearLayout parent, String name, String packageName,
                             String fallback, boolean featured) {
        LinearLayout tile = column();
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(7), dp(8), dp(7), dp(8));
        int stroke = neon ? (featured ? CYAN : Color.rgb(35, 92, 135)) : Color.rgb(57, 67, 82);
        tile.setBackground(panel(featured ? Color.rgb(13, 33, 51) : PANEL_HI, stroke, 17));

        int iconColor = neon ? (featured ? CYAN : BLUE) : WHITE;
        if (neon) {
            NeonAppIconView icon = new NeonAppIconView(shortcutIconKind(name, packageName), iconColor);
            int iconWidth = iconScale == 0 ? 44 : (iconScale == 2 ? 58 : 52);
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(iconWidth), 0, 1);
            iconParams.gravity = Gravity.CENTER;
            tile.addView(icon, iconParams);
        } else {
            ImageView icon = new ImageView(this);
            Drawable appIcon = null;
            try { appIcon = getPackageManager().getApplicationIcon(packageName); }
            catch (Exception ignored) {
                for (ResolveInfo info : launchableApps()) {
                    String candidate = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
                    if (candidate.contains(fallback.toLowerCase(Locale.ROOT))) {
                        appIcon = info.loadIcon(getPackageManager());
                        break;
                    }
                }
            }
            if (appIcon != null) icon.setImageDrawable(appIcon);
            else icon.setImageDrawable(getDrawable(android.R.drawable.sym_def_app_icon));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int iconDp = iconScale == 0 ? 34 : (iconScale == 2 ? 52 : 43);
            LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(dp(iconDp), 0, 1);
            imageParams.gravity = Gravity.CENTER;
            tile.addView(icon, imageParams);
        }
        TextView caption = label(name.toUpperCase(Locale.getDefault()), iconScale == 0 ? 9 : 10, WHITE, true);
        caption.setGravity(Gravity.CENTER);
        tile.addView(caption);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.rightMargin = dp(7);
        parent.addView(tile, lp);
        tile.setOnClickListener(v -> launchPackageOrFind(packageName, fallback, name));
        tile.setContentDescription("Open " + name);
        tile.setMinimumHeight(dp(48));
    }

    private static final int ICON_GENERIC = 0;
    private static final int ICON_PLAY = 1;
    private static final int ICON_CAR = 2;
    private static final int ICON_NAVIGATION = 3;
    private static final int ICON_SPOTIFY = 4;

    private int shortcutIconKind(String name, String packageName) {
        String value = (name + " " + packageName).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (value.contains("diplay") || value.contains("carplay")) return ICON_PLAY;
        if (value.contains("diauto") || value.contains("androidauto") || value.contains("gearhead")) return ICON_CAR;
        if (value.contains("waze")) return ICON_NAVIGATION;
        if (value.contains("spotify")) return ICON_SPOTIFY;
        return ICON_GENERIC;
    }

    /** Simple canvas icons avoid font and emoji coverage differences on older head units. */
    private final class NeonAppIconView extends View {
        private final int kind;
        private final int accent;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        NeonAppIconView(int kind, int accent) {
            super(MainActivity.this);
            this.kind = kind;
            this.accent = accent;
            setContentDescription(iconDescription(kind));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float size = Math.min(getWidth(), getHeight()) * 0.84f;
            if (size <= 0) return;
            canvas.save();
            canvas.translate((getWidth() - size) / 2f, (getHeight() - size) / 2f);
            canvas.scale(size / 48f, size / 48f);
            paint.setStrokeWidth(3f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(accent);

            switch (kind) {
                case ICON_PLAY:
                    drawPlay(canvas);
                    break;
                case ICON_CAR:
                    drawCar(canvas);
                    break;
                case ICON_NAVIGATION:
                    drawNavigation(canvas);
                    break;
                case ICON_SPOTIFY:
                    drawSpotify(canvas);
                    break;
                default:
                    drawGeneric(canvas);
                    break;
            }
            canvas.restore();
        }

        private void drawPlay(Canvas canvas) {
            canvas.drawRoundRect(8, 11, 40, 37, 6, 6, paint);
            paint.setStyle(Paint.Style.FILL);
            path.reset();
            path.moveTo(20, 17);
            path.lineTo(32, 24);
            path.lineTo(20, 31);
            path.close();
            canvas.drawPath(path, paint);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawLine(15, 42, 33, 42, paint);
        }

        private void drawCar(Canvas canvas) {
            path.reset();
            path.moveTo(7, 30);
            path.lineTo(10, 25);
            path.quadTo(11, 23, 14, 22);
            path.lineTo(19, 14);
            path.quadTo(20, 12, 23, 12);
            path.lineTo(31, 12);
            path.quadTo(33, 12, 34, 15);
            path.lineTo(38, 23);
            path.quadTo(41, 24, 42, 28);
            path.lineTo(42, 34);
            path.lineTo(7, 34);
            path.close();
            canvas.drawPath(path, paint);
            canvas.drawLine(15, 23, 35, 23, paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(15, 35, 4, paint);
            canvas.drawCircle(34, 35, 4, paint);
        }

        private void drawNavigation(Canvas canvas) {
            path.reset();
            path.moveTo(24, 42);
            path.cubicTo(20, 36, 10, 27, 10, 20);
            path.cubicTo(10, 12, 16, 7, 24, 7);
            path.cubicTo(32, 7, 38, 12, 38, 20);
            path.cubicTo(38, 27, 28, 36, 24, 42);
            path.close();
            canvas.drawPath(path, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(10, 35, 47));
            canvas.drawCircle(24, 20, 7, paint);
            path.reset();
            path.moveTo(20, 23);
            path.lineTo(29, 17);
            path.lineTo(26, 27);
            path.lineTo(23, 23);
            path.close();
            paint.setColor(accent);
            canvas.drawPath(path, paint);
        }

        private void drawSpotify(Canvas canvas) {
            canvas.drawCircle(24, 24, 18, paint);
            paint.setStrokeWidth(3.3f);
            path.reset();
            path.moveTo(13, 19);
            path.cubicTo(20, 16, 29, 17, 35, 21);
            canvas.drawPath(path, paint);
            paint.setStrokeWidth(2.8f);
            path.reset();
            path.moveTo(15, 25);
            path.cubicTo(21, 22, 29, 23, 33, 26);
            canvas.drawPath(path, paint);
            paint.setStrokeWidth(2.4f);
            path.reset();
            path.moveTo(17, 30);
            path.cubicTo(22, 28, 27, 29, 31, 31);
            canvas.drawPath(path, paint);
        }

        private void drawGeneric(Canvas canvas) {
            canvas.drawRoundRect(9, 9, 39, 39, 8, 8, paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(24, 24, 4, paint);
        }

        private String iconDescription(int iconKind) {
            switch (iconKind) {
                case ICON_PLAY: return "Media player icon";
                case ICON_CAR: return "Car app icon";
                case ICON_NAVIGATION: return "Navigation icon";
                case ICON_SPOTIFY: return "Spotify icon";
                default: return "App icon";
            }
        }
    }

    private void addAppDrawerShortcut(LinearLayout parent) {
        LinearLayout tile = column();
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(7), dp(8), dp(7), dp(8));
        tile.setBackground(panel(PANEL_HI, neon ? Color.rgb(35, 92, 135) : Color.rgb(57, 67, 82), 17));
        TextView icon = label("▦", 28, neon ? CYAN : WHITE, true);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView caption = label("ALL APPS", iconScale == 0 ? 9 : 10, WHITE, true);
        caption.setGravity(Gravity.CENTER);
        tile.addView(caption);
        parent.addView(tile, new LinearLayout.LayoutParams(0, -1, 1));
        tile.setOnClickListener(v -> showApps());
    }

    private ArrayList<ResolveInfo> selectedQuickLaunchApps() {
        String saved = prefs.getString("quick_launch", null);
        String[] packages = saved == null
                ? new String[]{"com.shihab.diplay", "com.waze", "com.google.android.apps.maps"}
                : saved.split(",");
        List<ResolveInfo> installed = launchableApps();
        ArrayList<ResolveInfo> result = new ArrayList<>();
        for (String packageName : packages) {
            for (ResolveInfo info : installed) {
                if (info.activityInfo.packageName.equals(packageName)) {
                    result.add(info);
                    break;
                }
            }
            if (result.size() == 4) break;
        }
        return result;
    }

    private void addChooseAppTile(LinearLayout parent) {
        LinearLayout tile = column();
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(7), dp(8), dp(7), dp(8));
        tile.setBackground(panel(PANEL_HI, neon ? Color.rgb(35, 92, 135) : Color.rgb(57, 67, 82), 17));
        TextView icon = label("+", 30, CYAN, true);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView caption = label("ADD APP", 10, WHITE, true);
        caption.setGravity(Gravity.CENTER);
        tile.addView(caption);
        parent.addView(tile, new LinearLayout.LayoutParams(0, -1, 1));
        tile.setOnClickListener(v -> chooseQuickLaunchApps());
    }

    private void chooseQuickLaunchApps() {
        List<ResolveInfo> apps = launchableApps();
        String[] names = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        ArrayList<String> selected = new ArrayList<>();
        for (ResolveInfo info : selectedQuickLaunchApps()) selected.add(info.activityInfo.packageName);
        for (int i = 0; i < apps.size(); i++) {
            ResolveInfo info = apps.get(i);
            names[i] = info.loadLabel(getPackageManager()).toString();
            checked[i] = selected.contains(info.activityInfo.packageName);
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Choose up to 4 apps")
                .setMultiChoiceItems(names, checked, (d, which, isChecked) -> {
                    String pkg = apps.get(which).activityInfo.packageName;
                    if (isChecked) {
                        if (selected.size() >= 4) {
                            ((AlertDialog) d).getListView().setItemChecked(which, false);
                            Toast.makeText(this, "Choose up to 4 apps", Toast.LENGTH_SHORT).show();
                        } else if (!selected.contains(pkg)) selected.add(pkg);
                    } else selected.remove(pkg);
                })
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, which) -> {
                    StringBuilder value = new StringBuilder();
                    for (String pkg : selected) {
                        if (value.length() > 0) value.append(',');
                        value.append(pkg);
                    }
                    prefs.edit().putString("quick_launch", value.toString()).apply();
                    buildHome();
                }).create();
        dialog.show();
    }

    private void addFooter(LinearLayout page, int selected) {
        LinearLayout footer = row();
        footer.setPadding(dp(4), dp(3), dp(4), 0);
        String[] labels = {"HOME", "SWITCH", "CARPLAY", "APPS", "SETTINGS"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            boolean isCarPlay = index == 2;
            TextView item = label(labels[i], isCarPlay ? 11 : 10,
                    isCarPlay ? BG : (selected == i ? CYAN : MUTED), true);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(isCarPlay ? 15 : 7), dp(10), dp(isCarPlay ? 15 : 7), dp(10));
            if (isCarPlay) item.setBackground(panel(CYAN, CYAN, 16));
            else if (selected == i) item.setBackground(panel(Color.rgb(11, 35, 51), Color.rgb(0, 100, 145), 14));
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(0, dp(48), isCarPlay ? 1.35f : 1f);
            itemParams.setMargins(dp(3), 0, dp(3), 0);
            footer.addView(item, itemParams);
            item.setMinimumHeight(dp(48));
            item.setContentDescription(labels[i]);
            item.setOnClickListener(v -> {
                if (index == 0) buildHome();
                else if (index == 1) showAppSwitcher();
                else if (index == 2) launchPackageOrFind("com.shihab.diplay", "diplay", "DiPlay / CarPlay");
                else if (index == 3) showApps();
                else showSettings();
            });
        }
        page.addView(footer, new LinearLayout.LayoutParams(-1, dp(50)));
    }

    private long getVerifiedDashboardTimeMillis() {
        SharedPreferences timePrefs = getSharedPreferences("neodash_time", MODE_PRIVATE);
        if (!timePrefs.getBoolean("verified", false)) return -1L;
        long baseElapsed = timePrefs.getLong("verified_elapsed", -1L);
        long baseEpoch = timePrefs.getLong("verified_epoch", -1L);
        long nowElapsed = SystemClock.elapsedRealtime();
        int currentBootCount;
        try { currentBootCount = Settings.Global.getInt(getContentResolver(), "boot_count", -1); }
        catch (RuntimeException ignored) { currentBootCount = -1; }
        int savedBootCount = timePrefs.getInt("boot_count", -1);
        if (currentBootCount < 0 || savedBootCount != currentBootCount
                || baseElapsed < 0L || baseEpoch < 0L || nowElapsed < baseElapsed) return -1L;
        return baseEpoch + (nowElapsed - baseElapsed);
    }

    private void updateClock() {
        if (clockView == null) return;
        long trustedNow = getVerifiedDashboardTimeMillis();
        if (trustedNow < 0L) {
            clockView.setText("--:--");
            if (dateView != null) dateView.setText("VERIFYING DATE & TIME");
            if (timeProgress != null) timeProgress.setVisibility(View.VISIBLE);
            if (timeStatusView != null) timeStatusView.setText("Checking Android · Google · NTP · GPS time...");
            return;
        }

        Date now = new Date(trustedNow);
        java.util.TimeZone manila = java.util.TimeZone.getTimeZone(DASHBOARD_TIME_ZONE);
        SimpleDateFormat clockFormat = new SimpleDateFormat("h:mm a", Locale.getDefault());
        clockFormat.setTimeZone(manila);
        clockView.setText(clockFormat.format(now));
        if (dateView != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE  •  dd MMMM yyyy", Locale.getDefault());
            dateFormat.setTimeZone(manila);
            dateView.setText(dateFormat.format(now).toUpperCase(Locale.getDefault()));
        }
        if (timeProgress != null) timeProgress.setVisibility(View.GONE);
        if (timeStatusView != null) {
            String source = getSharedPreferences("neodash_time", MODE_PRIVATE)
                    .getString("source", "Trusted time source");
            timeStatusView.setText("TIME VERIFIED  ·  " + source + "  ·  MANILA / GMT+8");
        }
    }

    private List<ResolveInfo> launchableApps() {
        if (cachedLaunchableApps != null) return cachedLaunchableApps;
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = getPackageManager().queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(
                        b.loadLabel(getPackageManager()).toString());
            }
        });
        cachedLaunchableApps = apps;
        return cachedLaunchableApps;
    }

    private void launchPackageOrFind(String packageName, String fallback, String displayName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) {
            for (ResolveInfo info : launchableApps()) {
                String label = info.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
                String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
                if (label.contains(fallback.toLowerCase(Locale.ROOT)) || pkg.contains(fallback.toLowerCase(Locale.ROOT))) {
                    intent = getPackageManager().getLaunchIntentForPackage(info.activityInfo.packageName);
                    if (intent != null) break;
                }
            }
        }
        if (intent != null) {
            rememberRecent(intent.getComponent() != null ? intent.getComponent().getPackageName() : packageName);
            try { startActivity(intent); }
            catch (Exception ex) { Toast.makeText(this, "Unable to open " + displayName, Toast.LENGTH_SHORT).show(); }
        } else {
            Toast.makeText(this, displayName + " is not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchExistingMedia() {
        String[] matches = {"music", "spotify", "youtube music", "poweramp", "vlc", "foobar"};
        for (ResolveInfo info : launchableApps()) {
            String name = info.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
            String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
            for (String match : matches) {
                if (name.contains(match) || pkg.contains(match.replace(" ", ""))) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(info.activityInfo.packageName);
                    if (launch != null) { rememberRecent(info.activityInfo.packageName); startActivity(launch); return; }
                }
            }
        }
        Toast.makeText(this, "Open your head unit's music app from All Apps", Toast.LENGTH_LONG).show();
    }

    private void rememberRecent(String packageName) {
        if (packageName == null || packageName.equals(getPackageName())) return;
        recentPackages.remove(packageName);
        recentPackages.add(0, packageName);
        while (recentPackages.size() > 8) recentPackages.remove(recentPackages.size() - 1);
        saveRecentPackages();
    }

    private void saveRecentPackages() {
        prefs.edit().putStringSet("recent_packages", new LinkedHashSet<>(recentPackages)).apply();
    }

    private void requestBackgroundClose(String packageName) {
        if (packageName == null || packageName.equals(getPackageName())) return;
        try {
            ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (manager != null) manager.killBackgroundProcesses(packageName);
        } catch (RuntimeException ignored) {
            // The app is still removed from NeoDash's switcher if Android declines the request.
        }
    }

    private void closeRecentApp(String packageName, String appName) {
        requestBackgroundClose(packageName);
        recentPackages.remove(packageName);
        saveRecentPackages();
        showAppSwitcher();
        Toast.makeText(this, "Close requested for " + appName, Toast.LENGTH_SHORT).show();
    }

    private void closeAllRecentApps() {
        ArrayList<String> packages = new ArrayList<>(recentPackages);
        for (String packageName : packages) requestBackgroundClose(packageName);
        recentPackages.clear();
        saveRecentPackages();
        showAppSwitcher();
        Toast.makeText(this, "Close requested for " + packages.size() + " apps", Toast.LENGTH_SHORT).show();
    }

    /** A lightweight launcher-level recent-app switcher. Android's protected global Recents UI
     * is not directly callable by an ordinary launcher, so this lists apps opened from NeoDash. */
    private void showAppSwitcher() {
        LinearLayout page = column();
        page.setPadding(dp(22), dp(17), dp(22), dp(12));
        setPage(page);
        LinearLayout header = row();
        header.addView(label("APP SWITCHER", 22, WHITE, true));
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView closeAll = label("CLOSE ALL", 10, CYAN, true);
        closeAll.setGravity(Gravity.CENTER);
        closeAll.setPadding(dp(10), dp(8), dp(10), dp(8));
        closeAll.setBackground(panel(PANEL_HI, Color.rgb(0, 100, 120), 12));
        LinearLayout.LayoutParams closeAllParams = new LinearLayout.LayoutParams(-2, dp(44));
        closeAllParams.rightMargin = dp(8);
        header.addView(closeAll, closeAllParams);
        closeAll.setMinimumWidth(dp(48));
        closeAll.setContentDescription("Close all recent apps");
        closeAll.setOnClickListener(v -> closeAllRecentApps());
        TextView home = label("HOME  ‹", 11, CYAN, true);
        home.setGravity(Gravity.CENTER);
        home.setMinimumWidth(dp(64));
        home.setMinimumHeight(dp(48));
        header.addView(home);
        home.setOnClickListener(v -> buildHome());
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView hint = label("Recently opened from NeoDash · tap an app to return", 11, MUTED, false);
        hint.setPadding(0, dp(4), 0, dp(10));
        page.addView(hint);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = column();
        boolean any = false;
        for (String packageName : new ArrayList<>(recentPackages)) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch == null) continue;
            any = true;
            String appName;
            Drawable appIcon;
            try {
                appName = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packageName, 0)).toString();
                appIcon = getPackageManager().getApplicationIcon(packageName);
            } catch (Exception ex) { appName = packageName; appIcon = getDrawable(android.R.drawable.sym_def_app_icon); }
            LinearLayout card = row();
            card.setPadding(dp(14), dp(4), dp(10), dp(4));
            card.setBackground(panel(PANEL, LINE, 14));
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(appIcon);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            card.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));
            TextView title = label(appName, 14, WHITE, true);
            title.setPadding(dp(12), 0, 0, 0);
            card.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
            TextView open = label("OPEN  ›", 10, CYAN, true);
            open.setPadding(dp(6), 0, dp(8), 0);
            card.addView(open);
            TextView close = label("×", 27, Color.rgb(255, 126, 130), true);
            close.setGravity(Gravity.CENTER);
            close.setBackground(panel(Color.rgb(43, 35, 39), Color.rgb(94, 61, 66), 12));
            close.setContentDescription("Close " + appName);
            LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(48), dp(48));
            closeParams.leftMargin = dp(6);
            card.addView(close, closeParams);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(58));
            cp.setMargins(0, dp(4), 0, dp(4));
            list.addView(card, cp);
            final String target = packageName;
            final String targetName = appName;
            card.setOnClickListener(v -> launchPackageOrFind(target, target, appNameSafe(target)));
            close.setOnClickListener(v -> closeRecentApp(target, targetName));
        }
        if (!any) {
            TextView empty = label("No recent apps yet. Open DiPlay or another app from the dashboard, then return here to switch back to it.", 14, MUTED, false);
            empty.setPadding(dp(18), dp(20), dp(18), dp(20));
            empty.setBackground(panel(PANEL, LINE, 16));
            list.addView(empty);
        }
        scroll.addView(list);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addFooter(page, 1);
    }

    private String appNameSafe(String packageName) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packageName, 0)).toString(); }
        catch (Exception ex) { return packageName; }
    }

    private void showApps() {
        LinearLayout page = column();
        page.setPadding(dp(22), dp(17), dp(22), dp(12));
        setPage(page);
        LinearLayout header = row();
        header.addView(label("ALL APPS", 22, WHITE, true));
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView back = label("HOME  ‹", 11, CYAN, true);
        header.addView(back);
        back.setOnClickListener(v -> buildHome());
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(40)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setUseDefaultMargins(false);
        List<ResolveInfo> apps = launchableApps();
        for (ResolveInfo info : apps) {
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(5), dp(12), dp(5), dp(10));
            item.setBackground(panel(PANEL, 0, 14));
            ImageView icon = new ImageView(this);
            try { icon.setImageDrawable(info.loadIcon(getPackageManager())); }
            catch (Exception ignored) { }
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            item.addView(icon, new LinearLayout.LayoutParams(dp(39), dp(39)));
            TextView name = label(info.loadLabel(getPackageManager()).toString(), 10, WHITE, true);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setPadding(dp(2), dp(8), dp(2), 0);
            item.addView(name, new LinearLayout.LayoutParams(-1, dp(34)));
            GridLayout.LayoutParams cell = new GridLayout.LayoutParams();
            cell.width = 0;
            cell.height = dp(92);
            cell.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            cell.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(item, cell);
            item.setOnClickListener(v -> {
                Intent launch = getPackageManager().getLaunchIntentForPackage(info.activityInfo.packageName);
                if (launch != null) { rememberRecent(info.activityInfo.packageName); startActivity(launch); }
            });
        }
        scroll.addView(grid);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollParams.topMargin = dp(12);
        page.addView(scroll, scrollParams);
        addFooter(page, 1);
    }

    private void showSettings() {
        LinearLayout page = column();
        page.setPadding(dp(24), dp(18), dp(24), dp(12));
        setPage(page);
        LinearLayout header = row();
        header.addView(label("SETTINGS", 23, WHITE, true));
        View gap = new View(this);
        header.addView(gap, new LinearLayout.LayoutParams(0, 1, 1));
        TextView back = label("HOME  ‹", 11, CYAN, true);
        header.addView(back);
        back.setOnClickListener(v -> buildHome());
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));

        ScrollView settingsScroll = new ScrollView(this);
        settingsScroll.setFillViewport(false);
        LinearLayout body = column();
        body.setPadding(dp(19), dp(17), dp(19), dp(17));
        body.setBackground(panel(PANEL, LINE, 19));
        settingsScroll.addView(body);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(-1, 0, 1);
        bodyParams.topMargin = dp(12);
        page.addView(settingsScroll, bodyParams);

        body.addView(label("ICON APPEARANCE", 11, CYAN, true));
        body.addView(label("Choose how NeoDash shortcut icons are presented.", 12, MUTED, false));
        LinearLayout styles = row();
        styles.setPadding(0, dp(12), 0, dp(19));
        addSettingChoice(styles, "NEON", neon, () -> { neon = true; prefs.edit().putBoolean("neon", true).apply(); showSettings(); });
        addSettingChoice(styles, "STANDARD", !neon, () -> { neon = false; prefs.edit().putBoolean("neon", false).apply(); showSettings(); });
        body.addView(styles);

        body.addView(label("ICON SIZE", 11, CYAN, true));
        body.addView(label("Adjust the shortcut tiles for your screen and touch preference.", 12, MUTED, false));
        LinearLayout sizes = row();
        sizes.setPadding(0, dp(12), 0, dp(19));
        addSettingChoice(sizes, "COMPACT", iconScale == 0, () -> setIconScale(0));
        addSettingChoice(sizes, "COMFORT", iconScale == 1, () -> setIconScale(1));
        addSettingChoice(sizes, "LARGE", iconScale == 2, () -> setIconScale(2));
        body.addView(sizes);

        body.addView(label("ABOUT NEODASH", 11, CYAN, true));
        TextView about = label("Version 0.3.0 · Lightweight launcher · DiPlay stays a separate app. Custom third-party icon packs can be added in a later update.", 12, MUTED, false);
        about.setPadding(0, dp(7), 0, 0);
        body.addView(about);

        TextView serviceHeading = label("DEVICE SERVICES", 11, CYAN, true);
        LinearLayout.LayoutParams serviceHeadingParams = new LinearLayout.LayoutParams(-1, dp(24));
        serviceHeadingParams.topMargin = dp(12);
        body.addView(serviceHeading, serviceHeadingParams);
        TextView serviceStatus = label(getSystemStatusText(), 12, MUTED, false);
        serviceStatus.setTag("system_service_status");
        serviceStatus.setPadding(0, dp(2), 0, dp(7));
        body.addView(serviceStatus);
        body.addView(label("TIME SYNCHRONIZATION", 11, CYAN, true));
        TextView timeSyncStatus = label(getTimeSyncStatusText(), 12, MUTED, false);
        timeSyncStatus.setTag("time_sync_status");
        body.addView(timeSyncStatus);

        TextView inputHeading = label("PHYSICAL BUTTON INPUT", 11, CYAN, true);
        LinearLayout.LayoutParams inputHeadingParams = new LinearLayout.LayoutParams(-1, dp(24));
        inputHeadingParams.topMargin = dp(12);
        body.addView(inputHeading, inputHeadingParams);
        physicalKeyStatusView = label(getLastPhysicalKeyText(), 12, MUTED, false);
        physicalKeyStatusView.setTag("physical_key_status");
        body.addView(physicalKeyStatusView);
        body.addView(label("Use the head unit's D-pad, OK, Back or Menu buttons to navigate. Media transport keys are passed to Android's active media player.", 11, MUTED, false));

        LinearLayout serviceLinks = row();
        addSystemShortcut(serviceLinks, "DATE / TIME", Settings.ACTION_DATE_SETTINGS);
        addSystemShortcut(serviceLinks, "LOCATION", Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        addSystemShortcut(serviceLinks, "BLUETOOTH", Settings.ACTION_BLUETOOTH_SETTINGS);
        addSystemShortcut(serviceLinks, "WI-FI", Settings.ACTION_WIFI_SETTINGS);
        body.addView(serviceLinks);
        addFooter(page, 2);
    }

    private String getSystemStatusText() {
        String zone = java.util.TimeZone.getDefault().getID();
        boolean gmt8 = java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) == 8 * 60 * 60 * 1000;
        boolean autoTime = Settings.Global.getInt(getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
        boolean autoZone = Settings.Global.getInt(getContentResolver(), Settings.Global.AUTO_TIME_ZONE, 0) == 1;
        return "Clock: Android system time · Auto time " + (autoTime ? "ON" : "OFF")
                + " · Auto zone " + (autoZone ? "ON" : "OFF") + " · " + zone + (gmt8 ? " (GMT+8)" : " (not GMT+8)");
    }

    private String getTimeSyncStatusText() {
        SharedPreferences timePrefs = getSharedPreferences("neodash_time", MODE_PRIVATE);
        if (!timePrefs.getBoolean("verified", false)) return "Time is not yet verified. NeoDash is checking independent sources.";
        String source = timePrefs.getString("source", "Trusted time source");
        boolean systemAligned = timePrefs.getBoolean("system_clock_aligned", false);
        return "Verified by " + source + " · " + (systemAligned
                ? "Android system clock aligned" : "NeoDash dashboard clock synchronized; Android system-clock privilege not available");
    }

    private String getLastPhysicalKeyText() {
        String last = prefs == null ? null : prefs.getString("last_hardware_key", null);
        return last == null ? "No physical key detected yet. Press a head-unit button to test." : "Last detected: " + last;
    }

    private void recordPhysicalKey(KeyEvent event) {
        String key = KeyEvent.keyCodeToString(event.getKeyCode());
        if (key.startsWith("KEYCODE_")) key = key.substring("KEYCODE_".length());
        InputDevice device = event.getDevice();
        String deviceName = device == null ? "Android input" : device.getName();
        int sources = device == null ? 0 : device.getSources();
        int deviceId = device == null ? -1 : device.getId();
        String description = key + " · scan " + event.getScanCode() + " · " + deviceName
                + " · device " + deviceId + " · sources 0x" + Integer.toHexString(sources);
        prefs.edit().putString("last_hardware_key", description).apply();
        if (physicalKeyStatusView != null) physicalKeyStatusView.setText("Last detected: " + description);
    }

    private void addSystemShortcut(LinearLayout parent, String title, String action) {
        TextView item = label(title, 9, WHITE, true);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(5), dp(7), dp(5), dp(7));
        item.setBackground(panel(PANEL_HI, LINE, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.rightMargin = dp(5);
        parent.addView(item, lp);
        item.setOnClickListener(v -> {
            try { startActivity(new Intent(action)); }
            catch (Exception ex) { Toast.makeText(this, "Android settings screen unavailable", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void addSettingChoice(LinearLayout parent, String title, boolean selected, Runnable action) {
        TextView choice = label(title, 11, selected ? BG : WHITE, true);
        choice.setGravity(Gravity.CENTER);
        choice.setPadding(dp(13), dp(10), dp(13), dp(10));
        choice.setBackground(panel(selected ? CYAN : PANEL_HI, selected ? CYAN : LINE, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.rightMargin = dp(8);
        parent.addView(choice, lp);
        choice.setOnClickListener(v -> action.run());
    }

    private void setIconScale(int value) {
        iconScale = value;
        prefs.edit().putInt("icon_scale", value).apply();
        showSettings();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            recordPhysicalKey(event);
            int code = event.getKeyCode();
            if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_BUTTON_START) {
                showApps();
                return true;
            }
            if (code == KeyEvent.KEYCODE_BUTTON_MODE) {
                showSettings();
                return true;
            }
            if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_BUTTON_B) {
                onBackPressed();
                return true;
            }
            // D-pad/Enter are left to Android's normal focus engine. Media and volume keys
            // are deliberately not consumed so the active media session/system keeps control.
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        buildHome();
    }

    @Override protected void onResume() {
        super.onResume();
        if (timeReceiver == null) {
            timeReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) { updateClock(); }
            };
            IntentFilter filter = new IntentFilter(Intent.ACTION_TIME_TICK);
            filter.addAction(Intent.ACTION_TIME_CHANGED);
            filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            filter.addAction(Intent.ACTION_DATE_CHANGED);
            registerReceiver(timeReceiver, filter);
        }
        if (statusReceiver == null) {
            statusReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    View status = findViewWithTag("system_service_status");
                    if (status instanceof TextView) ((TextView) status).setText(getSystemStatusText());
                    updateClock();
                    View timeStatus = findViewWithTag("time_sync_status");
                    if (timeStatus instanceof TextView) ((TextView) timeStatus).setText(getTimeSyncStatusText());
                    View inputStatus = findViewWithTag("physical_key_status");
                    if (inputStatus instanceof TextView) ((TextView) inputStatus).setText(getLastPhysicalKeyText());
                }
            };
            IntentFilter statusFilter = new IntentFilter(NeoDashConnectionManager.ACTION_STATUS);
            statusFilter.addAction(NeoDashTimeSyncManager.ACTION_TIME_STATUS);
            registerReceiver(statusReceiver, statusFilter);
        }
        // Re-run lightweight time discovery while the launcher is foregrounded. This is
        // especially useful for the short GNSS probe, which must not run without permission.
        Intent timeRefresh = new Intent(this, NeoDashConnectionManager.class);
        timeRefresh.setAction(NeoDashConnectionManager.ACTION_REFRESH_TIME);
        try { startService(timeRefresh); } catch (RuntimeException ignored) { }
        clockHandler.removeCallbacks(clockTicker);
        clockHandler.post(clockTicker);
        updateClock();
        showPendingReceiverPrompt();
    }

    @Override protected void onPause() {
        clockHandler.removeCallbacks(clockTicker);
        if (timeReceiver != null) {
            unregisterReceiver(timeReceiver);
            timeReceiver = null;
        }
        if (statusReceiver != null) {
            unregisterReceiver(statusReceiver);
            statusReceiver = null;
        }
        super.onPause();
    }

    private void showPendingReceiverPrompt() {
        SharedPreferences connection = getSharedPreferences("neodash_connection", MODE_PRIVATE);
        if (!connection.getBoolean("receiver_active", false)) return;
        String session = connection.getString("session_id", null);
        if (session == null || session.equals(connection.getString("prompted_session", null))) return;
        String os = connection.getString("device_os", "");
        String receiver = connection.getString("receiver", "");
        // An already active receiver owns the display; never stack another launch prompt.
        if (connection.getBoolean("receiver_running", false)) return;
        final String targetPackage = "diplay".equalsIgnoreCase(receiver) ? "com.shihab.diplay" : "";
        final String fallback = "diplay".equalsIgnoreCase(receiver) ? "diplay" : "diauto";
        String message = "ios".equalsIgnoreCase(os)
                ? "Apple device detected. Would you like to launch DiPlay?"
                : "Android device detected. Would you like to launch DiAuto?";
        new AlertDialog.Builder(this)
                .setTitle("Compatible receiver detected")
                .setMessage(message)
                .setPositiveButton("LAUNCH", (dialog, which) -> {
                    connection.edit().putString("prompted_session", session).apply();
                    launchPackageOrFind(targetPackage, fallback,
                            "diplay".equalsIgnoreCase(receiver) ? "DiPlay" : "DiAuto");
                })
                .setNegativeButton("NOT NOW", (dialog, which) ->
                        connection.edit().putString("prompted_session", session).apply())
                .setOnCancelListener(dialog -> connection.edit().putString("prompted_session", session).apply())
                .show();
    }

    private View findViewWithTag(Object tag) {
        return getWindow().getDecorView().findViewWithTag(tag);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

}
