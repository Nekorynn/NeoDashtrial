package com.neodash.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;

/** Low-overhead, event-driven connection monitor with optional privileged time correction. */
public final class NeoDashConnectionManager extends Service {
    public static final String ACTION_STATUS = "com.neodash.launcher.CONNECTION_STATUS";
    public static final String ACTION_RECEIVER_SESSION = "com.neodash.launcher.RECEIVER_SESSION";
    public static final String ACTION_REFRESH_TIME = "com.neodash.launcher.REFRESH_TIME";
    public static final String EXTRA_CONNECTED = "connected";
    public static final String EXTRA_RECEIVER_RUNNING = "receiver_running";
    public static final String EXTRA_DEVICE_OS = "device_os";
    public static final String EXTRA_SESSION_ID = "session_id";
    public static final String EXTRA_RECEIVER = "receiver";

    private static final String CHANNEL = "neodash_connection";
    private BroadcastReceiver radioReceiver;
    private ConnectivityManager connectivity;
    private ConnectivityManager.NetworkCallback networkCallback;
    private boolean networkRegistered;
    private boolean usbRegistered;
    private boolean receiverSessionActive;
    private NeoDashTimeSyncManager timeSyncManager;
    private String receiverSessionId;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(7102, buildNotification("Monitoring device connections"));
        timeSyncManager = new NeoDashTimeSyncManager(this);
        timeSyncManager.start();
        registerEventSources();
        publishStatus();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // External receiver software may notify NeoDash of an established protocol session.
        // An OS type or Bluetooth device name alone is deliberately not considered a handshake.
        if (intent != null && ACTION_REFRESH_TIME.equals(intent.getAction()) && timeSyncManager != null) {
            timeSyncManager.refreshIfNeeded();
        }
        if (intent != null && ACTION_RECEIVER_SESSION.equals(intent.getAction())) {
            boolean connected = intent.getBooleanExtra(EXTRA_CONNECTED, false);
            String sessionId = intent.getStringExtra(EXTRA_SESSION_ID);
            if (connected && validSession(intent, sessionId)) {
                receiverSessionActive = true;
                receiverSessionId = sessionId;
                getSharedPreferences("neodash_connection", MODE_PRIVATE).edit()
                        .putBoolean("receiver_active", true)
                        .putBoolean("receiver_running", intent.getBooleanExtra(EXTRA_RECEIVER_RUNNING, false))
                        .putString("session_id", sessionId)
                        .putString("device_os", intent.getStringExtra(EXTRA_DEVICE_OS))
                        .putString("receiver", intent.getStringExtra(EXTRA_RECEIVER))
                        .apply();
                Intent event = new Intent(ACTION_RECEIVER_SESSION);
                event.setPackage(getPackageName());
                event.putExtras(intent);
                sendBroadcast(event);
            } else if (!connected) {
                receiverSessionActive = false;
                receiverSessionId = null;
                getSharedPreferences("neodash_connection", MODE_PRIVATE).edit()
                        .putBoolean("receiver_active", false).putBoolean("receiver_running", false)
                        .remove("session_id").remove("prompted_session").apply();
                Intent event = new Intent(ACTION_RECEIVER_SESSION);
                event.setPackage(getPackageName());
                event.putExtra(EXTRA_CONNECTED, false);
                event.putExtra(EXTRA_SESSION_ID, sessionId);
                sendBroadcast(event);
            }
        }
        publishStatus();
        return START_STICKY;
    }

    private boolean validSession(Intent intent, String id) {
        if (id == null || id.trim().length() == 0) return false;
        String os = intent.getStringExtra(EXTRA_DEVICE_OS);
        String receiver = intent.getStringExtra(EXTRA_RECEIVER);
        return ("ios".equalsIgnoreCase(os) || "android".equalsIgnoreCase(os))
                && (("ios".equalsIgnoreCase(os) && "diplay".equalsIgnoreCase(receiver))
                || ("android".equalsIgnoreCase(os) && "diauto".equalsIgnoreCase(receiver)));
    }

    private void registerEventSources() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null && !adapter.isEnabled()) {
            try { adapter.enable(); } catch (RuntimeException ignored) { }
        }
        radioReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_TIME_CHANGED.equals(intent.getAction()) && timeSyncManager != null) {
                    timeSyncManager.onSystemTimeChanged();
                }
                publishStatus();
            }
        };
        IntentFilter radios = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        radios.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
        radios.addAction(WifiActions.STATE_CHANGED);
        radios.addAction(WifiActions.NETWORK_STATE_CHANGED);
        radios.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        radios.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        radios.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
        radios.addAction(Intent.ACTION_TIME_CHANGED);
        radios.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        radios.addAction(Intent.ACTION_DATE_CHANGED);
        registerReceiver(radioReceiver, radios);

        connectivity = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivity != null && Build.VERSION.SDK_INT >= 24) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { if (timeSyncManager != null) timeSyncManager.refreshIfNeeded(); publishStatus(); }
                @Override public void onLost(Network network) { publishStatus(); }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) { publishStatus(); }
            };
            try {
                connectivity.registerNetworkCallback(new NetworkRequest.Builder().build(), networkCallback);
                networkRegistered = true;
            } catch (RuntimeException ignored) { }
        }
    }

    private void publishStatus() {
        Intent status = new Intent(ACTION_STATUS);
        status.setPackage(getPackageName());
        BluetoothAdapter bt = BluetoothAdapter.getDefaultAdapter();
        status.putExtra("bluetooth", bt != null && bt.isEnabled());
        status.putExtra("wifi", WifiActions.isWifiEnabled(this));
        status.putExtra("network", hasNetwork());
        status.putExtra("location", isLocationEnabled());
        status.putExtra("timezone", java.util.TimeZone.getDefault().getID());
        status.putExtra("gmt8", java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) == 8 * 60 * 60 * 1000);
        status.putExtra("receiver_active", receiverSessionActive);
        sendBroadcast(status);
    }

    private boolean hasNetwork() {
        if (connectivity == null) return false;
        if (Build.VERSION.SDK_INT >= 23) {
            Network network = connectivity.getActiveNetwork();
            NetworkCapabilities caps = network == null ? null : connectivity.getNetworkCapabilities(network);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }
        return connectivity.getActiveNetworkInfo() != null && connectivity.getActiveNetworkInfo().isConnected();
    }

    private boolean isLocationEnabled() {
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            return lm != null && (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER));
        } catch (RuntimeException ignored) { return false; }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "NeoDash connection monitor", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private Notification buildNotification(String text) {
        Intent launch = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, launch, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("NeoDash")
                .setContentText(text)
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        if (timeSyncManager != null) { timeSyncManager.stop(); timeSyncManager = null; }
        if (radioReceiver != null) {
            try { unregisterReceiver(radioReceiver); } catch (IllegalArgumentException ignored) { }
        }
        if (networkRegistered && connectivity != null && networkCallback != null) {
            try { connectivity.unregisterNetworkCallback(networkCallback); } catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static final class WifiActions {
        static final String STATE_CHANGED = "android.net.wifi.WIFI_STATE_CHANGED";
        static final String NETWORK_STATE_CHANGED = "android.net.wifi.STATE_CHANGE";
        static boolean isWifiEnabled(Context context) {
            try {
                android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) context.getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                return wm != null && wm.isWifiEnabled();
            } catch (RuntimeException ignored) { return false; }
        }
    }
}
