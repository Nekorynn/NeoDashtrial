package com.neodash.launcher;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;

import com.google.android.gms.time.TrustedTime;
import com.google.android.gms.time.TrustedTimeClient;
import com.google.android.gms.time.trustedtime.OnNewTimeSignalAvailableListener;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Map;
import java.security.SecureRandom;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Obtains a trusted UTC time without trusting the head unit's RTC/system clock.
 * All independent sources are started together. The dashboard clock is driven from
 * the accepted UTC value plus elapsedRealtime(), so a bad wall clock cannot corrupt it.
 */
public final class NeoDashTimeSyncManager {
    public static final String ACTION_TIME_STATUS = "com.neodash.launcher.TIME_STATUS";
    public static final String EXTRA_VERIFIED = "verified";
    public static final String EXTRA_SOURCE = "source";
    public static final String EXTRA_MESSAGE = "message";

    private static final long MIN_REASONABLE_UTC = 1704067200000L; // 2024-01-01
    private static final long MAX_REASONABLE_UTC = 4102444800000L; // 2100-01-01
    private static final long NTP_CONSENSUS_WINDOW_MS = 3000L;
    private static final String[] NTP_SERVERS = {
            "time.google.com", "time.cloudflare.com", "pool.ntp.org"
    };
    private static final String PREFS = "neodash_time";
    private static final SecureRandom NTP_NONCE_RANDOM = new SecureRandom();

    private final Context app;
    private final android.content.SharedPreferences preferences;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService workers = Executors.newFixedThreadPool(5);
    private final AtomicBoolean stopped = new AtomicBoolean(false);
    private final AtomicBoolean ntpRoundRunning = new AtomicBoolean(false);
    private final AtomicInteger ntpRoundGeneration = new AtomicInteger(0);

    private volatile boolean verified;
    private volatile String verifiedSource = "";
    private volatile TrustedTimeClient trustedClient;
    private volatile OnNewTimeSignalAvailableListener trustedListener;
    private volatile boolean googleClientRequested;
    private LocationManager locationManager;
    private LocationListener gnssProbeListener;
    private boolean gnssProbeActive;
    private final Runnable gnssProbeTimeout = this::stopGnssProbe;

    private final Runnable retryTask = new Runnable() {
        @Override public void run() {
            if (stopped.get()) return;
            probeAndroidClocks();
            if (!verified) {
                initializeGoogleTrustedTime();
                startNtpRound();
            } else {
                initializeGoogleTrustedTime();
                checkGoogleTrustedTime();
                startNtpRound();
            }
            main.removeCallbacks(this);
            main.postDelayed(this, verified ? 6L * 60L * 60L * 1000L : 30_000L);
        }
    };

    public NeoDashTimeSyncManager(Context context) {
        app = context.getApplicationContext();
        preferences = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void start() {
        if (stopped.get()) return;
        long savedElapsed = preferences.getLong("verified_elapsed", -1L);
        long nowElapsed = SystemClock.elapsedRealtime();
        int currentBootCount = readBootCount();
        int savedBootCount = preferences.getInt("boot_count", -1);
        // elapsedRealtime() resets at reboot. Only reuse a previous verification when
        // Android confirms this is the same boot session; otherwise show the progress bar.
        verified = preferences.getBoolean("verified", false)
                && currentBootCount >= 0 && savedBootCount == currentBootCount
                && savedElapsed >= 0L && nowElapsed >= savedElapsed;
        verifiedSource = verified ? preferences.getString("source", "Previously verified time") : "";
        if (!verified) preferences.edit().putBoolean("verified", false).apply();
        ensureManilaTimeZone();

        if (!verified) {
            preferences.edit().putBoolean("verified", false).apply();
            publish(false, "", "Checking available time sources...");
        } else {
            publish(true, verifiedSource, "Previously verified time; checking for a fresher signal...");
        }

        // These probes are deliberately independent and start together during boot.
        probeAndroidClocks();
        startGnssProbeIfPermitted();
        initializeGoogleTrustedTime();
        startNtpRound();
        main.removeCallbacks(retryTask);
        main.postDelayed(retryTask, verified ? 6L * 60L * 60L * 1000L : 30_000L);
    }

    private int readBootCount() {
        try {
            return Settings.Global.getInt(app.getContentResolver(), "boot_count", -1);
        } catch (RuntimeException ignored) {
            return -1;
        }
    }

    private void ensureManilaTimeZone() {
        boolean aligned = "Asia/Manila".equals(java.util.TimeZone.getDefault().getID());
        if (!aligned) {
            try {
                android.app.AlarmManager alarm = (android.app.AlarmManager)
                        app.getSystemService(Context.ALARM_SERVICE);
                if (alarm != null) {
                    alarm.setTimeZone("Asia/Manila");
                    aligned = "Asia/Manila".equals(java.util.TimeZone.getDefault().getID());
                }
            } catch (SecurityException ignored) {
                // SET_TIME_ZONE is privileged; dashboard formatting still uses Asia/Manila.
            } catch (RuntimeException ignored) { }
        }
        preferences.edit().putBoolean("system_timezone_aligned", aligned).apply();
    }

    /** Called when Android reports a new network becoming available. */
    public void refreshIfNeeded() {
        if (stopped.get()) return;
        probeAndroidClocks();
        if (!verified) startGnssProbeIfPermitted();
        initializeGoogleTrustedTime();
        startNtpRound();
    }

    /** Android's automatic time detector can apply network-time or carrier/NITZ suggestions. */
    public void onSystemTimeChanged() {
        if (stopped.get() || verified) return;
        try {
            boolean automaticTime = Settings.Global.getInt(
                    app.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
            long systemTime = System.currentTimeMillis();
            if (automaticTime && isPlausible(systemTime)) {
                acceptTime(systemTime, "Android automatic time service", true);
            }
        } catch (RuntimeException ignored) {
            // A device may restrict access to global settings; the other time sources continue.
        }
    }

    private void probeAndroidClocks() {
        if (stopped.get()) return;
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                long networkTime = android.os.SystemClock.currentNetworkTimeClock().millis();
                if (isPlausible(networkTime)) acceptTime(networkTime, "Android network time", true);
            } catch (Throwable ignored) {
                // Android returns no value when it has no recent network-time signal.
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                long gnssTime = android.os.SystemClock.currentGnssTimeClock().millis();
                if (isPlausible(gnssTime)) acceptTime(gnssTime, "GNSS satellite time", true);
            } catch (Throwable ignored) {
                // No GNSS fix since boot, unavailable provider, or a vendor implementation gap.
            }
        }
    }

    /**
     * If the user has already granted precise-location access, briefly request one GPS fix
     * so the platform can populate its GNSS time clock. No coordinates are stored or transmitted.
     * The request is bounded to 45 seconds and is skipped when permission is absent.
     */
    private synchronized void startGnssProbeIfPermitted() {
        if (stopped.get() || verified || gnssProbeActive) return;
        if (Build.VERSION.SDK_INT >= 23
                && app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;
        try {
            locationManager = (LocationManager) app.getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null || !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return;
            gnssProbeListener = new LocationListener() {
                @Override public void onLocationChanged(android.location.Location location) {
                    probeAndroidClocks();
                    stopGnssProbe();
                }
                @Override public void onStatusChanged(String provider, int status, android.os.Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { stopGnssProbe(); }
            };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f,
                    gnssProbeListener, Looper.getMainLooper());
            gnssProbeActive = true;
            main.postDelayed(gnssProbeTimeout, 45_000L);
        } catch (SecurityException ignored) {
            stopGnssProbe();
        } catch (RuntimeException ignored) {
            stopGnssProbe();
        }
    }

    private synchronized void stopGnssProbe() {
        main.removeCallbacks(gnssProbeTimeout);
        if (locationManager != null && gnssProbeListener != null) {
            try { locationManager.removeUpdates(gnssProbeListener); }
            catch (SecurityException ignored) { }
            catch (RuntimeException ignored) { }
        }
        gnssProbeListener = null;
        gnssProbeActive = false;
    }

    private synchronized void initializeGoogleTrustedTime() {
        if (stopped.get() || googleClientRequested || trustedClient != null) return;
        googleClientRequested = true;
        try {
            TrustedTime.createClient(app).addOnCompleteListener(task -> {
                if (stopped.get()) return;
                if (task.isSuccessful() && task.getResult() != null) {
                    trustedClient = task.getResult();
                    trustedListener = signal -> checkGoogleTrustedTime();
                    try { trustedClient.addTimeSignalListener(trustedListener); }
                    catch (RuntimeException ignored) { }
                    checkGoogleTrustedTime();
                } else {
                    googleClientRequested = false; // Retry later if Play Services becomes available.
                }
            });
        } catch (Throwable unavailable) {
            googleClientRequested = false;
        }
    }

    private void checkGoogleTrustedTime() {
        TrustedTimeClient client = trustedClient;
        if (stopped.get() || client == null) return;
        try {
            Long trustedMillis = client.computeCurrentUnixEpochMillis();
            if (trustedMillis != null && isPlausible(trustedMillis)) {
                acceptTime(trustedMillis, "Google Trusted Time", true);
            }
        } catch (Throwable ignored) {
            // Google Play Services is optional on many aftermarket head units.
        }
    }

    private void startNtpRound() {
        if (stopped.get() || !ntpRoundRunning.compareAndSet(false, true)) return;
        final int generation = ntpRoundGeneration.incrementAndGet();
        final Map<String, Long> roundResults = new ConcurrentHashMap<>();
        final AtomicInteger completed = new AtomicInteger(0);
        for (String server : NTP_SERVERS) {
            workers.execute(() -> {
                try {
                    long time = queryNtp(server);
                    if (isPlausible(time)) {
                        roundResults.put(server, time);
                        evaluateNtpConsensus(roundResults);
                    }
                } catch (Exception ignored) {
                    // A blocked UDP/123 path or unavailable server must not block other sources.
                } finally {
                    if (completed.incrementAndGet() >= NTP_SERVERS.length
                            && ntpRoundGeneration.get() == generation) {
                        ntpRoundRunning.set(false);
                    }
                }
            });
        }
        // A stuck DNS lookup cannot prevent later retries; old-round results stay isolated.
        main.postDelayed(() -> {
            if (ntpRoundGeneration.get() == generation) ntpRoundRunning.set(false);
        }, 8_000L);
    }

    private void evaluateNtpConsensus(Map<String, Long> roundResults) {
        if (roundResults.size() < 2) return;
        Long[] values = roundResults.values().toArray(new Long[0]);
        Arrays.sort(values);
        if (values[values.length - 1] - values[0] <= NTP_CONSENSUS_WINDOW_MS) {
            long median = values[values.length / 2];
            acceptTime(median, "NTP quorum (" + roundResults.size() + " servers)", true);
        }
    }

    private long queryNtp(String host) throws Exception {
        InetAddress address = InetAddress.getByName(host);
        byte[] packetData = new byte[48];
        packetData[0] = 0x23; // LI=0, VN=4, client mode=3.
        // NTP servers copy the client's transmit timestamp into the originate field.
        // A random nonce lets us reject stray or unrelated UDP packets without trusting RTC time.
        byte[] nonce = new byte[8];
        NTP_NONCE_RANDOM.nextBytes(nonce);
        System.arraycopy(nonce, 0, packetData, 40, nonce.length);
        DatagramPacket request = new DatagramPacket(packetData, packetData.length, address, 123);
        long startNanos = SystemClock.elapsedRealtimeNanos();
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.connect(address, 123);
            socket.setSoTimeout(2800);
            socket.send(request);
            DatagramPacket response = new DatagramPacket(new byte[48], 48);
            socket.receive(response);
            long endNanos = SystemClock.elapsedRealtimeNanos();
            byte[] data = response.getData();
            int leap = (data[0] >> 6) & 0x03;
            int version = (data[0] >> 3) & 0x07;
            int mode = data[0] & 0x07;
            int stratum = data[1] & 0xff;
            boolean originateMatches = true;
            for (int i = 0; i < 8; i++) {
                if (data[24 + i] != nonce[i]) { originateMatches = false; break; }
            }
            if (leap == 3 || version < 3 || mode != 4 || stratum < 1 || stratum > 15
                    || !originateMatches) {
                throw new IllegalStateException("Invalid NTP response from " + host);
            }
            long seconds = readUnsignedInt(data, 40);
            long fraction = readUnsignedInt(data, 44);
            if (seconds == 0L) throw new IllegalStateException("NTP response has no transmit time");

            // NTP epoch (1900) -> Unix epoch (1970). Select the era that falls in 2024-2100.
            long eraSeconds = seconds - 2_208_988_800L;
            long eraOneSeconds = eraSeconds + (1L << 32);
            long pivot = System.currentTimeMillis();
            if (!isPlausible(pivot)) pivot = 1_780_000_000_000L; // Safe era pivot near 2026.
            long unixSeconds = Math.abs(eraOneSeconds * 1000L - pivot)
                    < Math.abs(eraSeconds * 1000L - pivot) ? eraOneSeconds : eraSeconds;
            long serverTransmitMillis = unixSeconds * 1000L + ((fraction * 1000L) >>> 32);
            long roundTripMillis = Math.max(0L, (endNanos - startNanos) / 1_000_000L);
            return serverTransmitMillis + (roundTripMillis / 2L);
        }
    }

    private long readUnsignedInt(byte[] data, int offset) {
        return ((long) (data[offset] & 0xff) << 24)
                | ((long) (data[offset + 1] & 0xff) << 16)
                | ((long) (data[offset + 2] & 0xff) << 8)
                | (long) (data[offset + 3] & 0xff);
    }

    private boolean isPlausible(long utcMillis) {
        return utcMillis >= MIN_REASONABLE_UTC && utcMillis < MAX_REASONABLE_UTC;
    }

    private synchronized void acceptTime(long utcMillis, String source, boolean trySetSystemClock) {
        if (stopped.get() || !isPlausible(utcMillis)) return;
        // Re-anchor the dashboard clock whenever a fresh trusted signal arrives.
        // This also corrects gradual drift during long drives without trusting wall time.
        verified = true;
        verifiedSource = source;
        stopGnssProbe();
        long elapsed = SystemClock.elapsedRealtime();
        boolean systemClockSet = false;
        boolean systemClockAligned = false;
        if (trySetSystemClock) {
            try {
                long current = System.currentTimeMillis();
                if (Math.abs(current - utcMillis) <= 1500L) {
                    systemClockAligned = true;
                } else {
                    systemClockSet = android.os.SystemClock.setCurrentTimeMillis(utcMillis);
                    systemClockAligned = systemClockSet;
                }
            } catch (SecurityException ignored) {
                // SET_TIME is signature/privileged on Android; normal sideloaded apps cannot set it.
            } catch (RuntimeException ignored) { }
        }
        preferences.edit()
                .putBoolean("verified", true)
                .putLong("verified_epoch", utcMillis)
                .putLong("verified_elapsed", elapsed)
                .putInt("boot_count", readBootCount())
                .putString("source", source)
                .putBoolean("system_clock_set", systemClockSet)
                .putBoolean("system_clock_aligned", systemClockAligned)
                .apply();
        publish(true, source, systemClockSet
                ? "Time verified; Android system clock corrected."
                : (systemClockAligned ? "Time verified; Android system clock was already aligned."
                : "Time verified; dashboard clock synchronized."));
        main.removeCallbacks(retryTask);
        main.postDelayed(retryTask, 6L * 60L * 60L * 1000L);
    }

    private void publish(boolean isVerified, String source, String message) {
        Intent status = new Intent(ACTION_TIME_STATUS);
        status.setPackage(app.getPackageName());
        status.putExtra(EXTRA_VERIFIED, isVerified);
        status.putExtra(EXTRA_SOURCE, source == null ? "" : source);
        status.putExtra(EXTRA_MESSAGE, message == null ? "" : message);
        app.sendBroadcast(status);
    }

    public void stop() {
        if (!stopped.compareAndSet(false, true)) return;
        main.removeCallbacksAndMessages(null);
        stopGnssProbe();
        TrustedTimeClient client = trustedClient;
        OnNewTimeSignalAvailableListener listener = trustedListener;
        if (client != null) {
            try {
                if (listener != null) client.removeTimeSignalListener(listener);
                client.dispose();
            } catch (RuntimeException ignored) { }
        }
        workers.shutdownNow();
    }
}
