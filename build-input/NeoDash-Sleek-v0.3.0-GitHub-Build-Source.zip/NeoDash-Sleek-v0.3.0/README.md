# NeoDash 0.3.0 — Time Sync + Physical Input Foundation

A lightweight native Android HOME launcher prototype for an automotive head unit.

## Retained dashboard functionality

- Two-column landscape home dashboard with a large clock/date panel and a compact media shortcut.
- Four configurable quick-launch tiles, with up to four selected apps.
- App drawer showing installed launcher apps.
- Persistent Home / Switch / CarPlay / Apps / Settings navigation.
- Separate DiPlay shortcut and package lookup; DiPlay remains an independent app.
- Lightweight launcher-managed recent-app switcher (only tracks apps launched from NeoDash; it is not Android's protected global Recents list).
- Neon / Standard appearance and Compact / Comfort / Large icon-size preferences.
- Registered as both Android HOME and regular launcher activity.

## What's new in this update

- Corrected the Android Studio project layout: manifest and Java sources now live in the `app` module.
- Pinned Android Gradle Plugin 8.5.2 and Gradle 8.7, with Java 17 compatibility.
- Retained the existing native landscape dashboard, app drawer, quick-launch tiles, media shortcut and launcher-managed app switcher.
- Added a `NeoDashTimeSyncManager` that starts independent time probes during service startup:
  - Android network-time clock on Android 13+.
  - Android GNSS-time clock on Android 10+; if precise-location permission was already granted and GPS is enabled, NeoDash requests one short, bounded GPS fix (maximum 45 seconds) to populate the GNSS time clock. It does not store or transmit coordinates.
  - Google Play Services Trusted Time API when Google Play Services is installed and supported.
  - Parallel NTP requests to Google, Cloudflare and the NTP Pool; at least two agreeing responses are required for NTP quorum.
  - Android automatic network/mobile time service changes are considered when Android reports a system-time change and automatic time is enabled. Android does not expose a public app API that identifies whether that change came from NTP or carrier NITZ.
- The head unit's RTC/system wall clock is treated as an unverified starting value, not proof of correct time.
- Until a trusted source is obtained, the dashboard hides the potentially incorrect clock and date and displays an indeterminate progress bar.
- After verification, the dashboard clock is calculated from the verified UTC reading plus Android elapsed-realtime, updates every second, and is always displayed in `Asia/Manila` (GMT+8).
- NeoDash attempts to correct the actual Android system clock only when the OS grants the privileged `SET_TIME` permission. Normal sideloaded apps generally cannot receive this permission; in that case the NeoDash dashboard clock is still synchronized independently.
- Time synchronization runs alongside Bluetooth, Wi-Fi, USB, location and network monitoring; it does not hold up the rest of the launcher.
- Added Android physical-key handling and a Settings diagnostic showing the last key code, scan code and input device name.
- D-pad navigation and Enter/OK use Android's native focus engine; Menu opens the app drawer; Back returns home; supported mode/start buttons open Settings or the app drawer. Media transport and volume keys are passed through so Android's active media session and system volume controls keep working.

## Time-source notes and limitations

- Android's built-in network-time and telephony/NITZ detection is managed by the Android system. NeoDash does not attempt to replace that service or read private telephony internals.
- The public GNSS time clock is available from API 29 (Android 10), but it may be unavailable until the device's location provider has obtained a fix since boot. If precise-location permission is already granted and GPS is enabled, NeoDash requests one short GPS fix for up to 45 seconds, then unregisters. If permission is not granted, the GNSS probe is skipped and all other sources continue.
- Android's public network-time clock is available from API 33; older head units use Google's Trusted Time API if available and the independent NTP quorum.
- Google Trusted Time requires a compatible Google Play Services installation. It is optional; NeoDash continues without it.
- The app cannot set Android's system timezone or clock in a normal sideloaded install unless the head unit grants privileged `SET_TIME` / `SET_TIME_ZONE` access. The dashboard itself always formats time in `Asia/Manila`. If system-clock access is unavailable, other apps such as DiPlay or DiAuto may continue to see Android's old system time even while NeoDash's dashboard clock is correct.
- NTP may be blocked by some Wi-Fi networks or mobile providers. If all trusted sources are unavailable, the progress bar remains visible and all other NeoDash services continue running.
- The NTP check uses UDP port 123. It validates NTP server mode, version, stratum and the echoed request nonce, and requires at least two of the three configured servers to agree within three seconds. NTP is not cryptographically authenticated; independent-source agreement improves robustness but is not a security-grade time attestation.
- A verified time is reused after an app-process restart only when Android's boot counter confirms that the device has not rebooted. After a reboot, the progress bar returns until a fresh time source is obtained.

## Physical-button compatibility

Android normally delivers hardware buttons to the foreground Activity as `KeyEvent` values. NeoDash records the key name, scan code, Android input-device name, device ID and source flags in Settings.

Standard Android D-pad, Enter/OK, Back, Menu and compatible media-key events are supported. Some buttons (for example Home, Power and some volume keys) are handled by Android before an app can receive them. Steering-wheel or front-panel buttons that are translated by a proprietary MCU/CAN-bus service may arrive as vendor broadcasts or through a vendor SDK instead of Android key events; those require a head-unit-specific integration after the diagnostic test identifies the input path.

## Compatibility

- Minimum Android: API 24 (Android 7.0).
- Build configuration: compile SDK 34, target SDK 28.
- Intended initial head-unit target: Android 10.
- Landscape layout.
- Native Android Views; no Compose, media decoder, duplicate music player or heavy animation.
- DiPlay and DiAuto remain separate apps.

## Build

Open the extracted `NeoDash-Sleek` folder in Android Studio. Use JDK 17, install Android SDK Platform 34, allow Gradle to sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The project uses Android Gradle Plugin 8.5.2 and Gradle 8.7.

The ChatGPT runtime used for this source update does not have an Android SDK installed, and could not download the Gradle distribution because network access to `services.gradle.org` was unavailable. A successful Gradle build, APK build and physical head-unit test could not be performed here. Treat this as an updated source package awaiting an Android Studio build and device validation.

Because the debug build has the `.debug` application ID suffix and a locally generated signing key, it installs separately from the production package. The release variant keeps `com.neodash.launcher` and will require the matching signing key to update an existing production install.

## Git safety

This is a local ZIP copy only. No files were committed, pushed, branched, or changed in the GitHub repository.
